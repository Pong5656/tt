"use client";

import { useCallback, useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import RetroLayout from "@/components/RetroLayout";
import MarioGame from "@/components/MarioGame";
import { chapters } from "@/data/chapters";
import { getNormalQuestions, getBossQuestions } from "@/data/questions";

type Result = {
  score: number;
  coins: number;
  correct: number;
  wrong: number;
  hintsUsed: number;
  cleared: boolean;
} | null;

export default function ArcadeChapterPage() {
  const params = useParams<{ chapterId: string }>();
  const chapterId = params?.chapterId;

  const chapter = chapters.find((c) => c.id === chapterId);
  const normalQs = chapter ? getNormalQuestions(chapter.id) : [];
  const bossQs = chapter ? getBossQuestions(chapter.id) : [];

  const [result, setResult] = useState<Result>(null);
  const [runKey, setRunKey] = useState(0);

  const handleComplete = useCallback((r: NonNullable<Result>) => {
    setResult(r);
  }, []);

  useEffect(() => {
    if (!result || !chapterId) return;
    try {
      const key = `pixel-physics-${chapterId}`;
      const prevRaw = localStorage.getItem(key);
      const prev = prevRaw
        ? JSON.parse(prevRaw)
        : { bestScore: 0, attempts: 0, bestCorrect: 0, cleared: false };
      localStorage.setItem(
        key,
        JSON.stringify({
          bestScore: Math.max(prev.bestScore ?? 0, result.score),
          attempts: (prev.attempts ?? 0) + 1,
          bestCorrect: Math.max(prev.bestCorrect ?? 0, result.correct),
          cleared: prev.cleared || result.cleared,
          lastPlayed: Date.now(),
        })
      );
      const totalRaw = localStorage.getItem("pixel-physics-total");
      const total = totalRaw
        ? JSON.parse(totalRaw)
        : { totalScore: 0, totalAttempts: 0, totalHints: 0 };
      localStorage.setItem(
        "pixel-physics-total",
        JSON.stringify({
          totalScore: (total.totalScore ?? 0) + result.score,
          totalAttempts: (total.totalAttempts ?? 0) + 1,
          totalHints: (total.totalHints ?? 0) + result.hintsUsed,
        })
      );
    } catch (e) {
      console.error("save failed", e);
    }
  }, [result, chapterId]);

  if (!chapter) {
    return (
      <RetroLayout>
        <div className="max-w-3xl mx-auto px-4 py-16 text-center">
          <div className="text-6xl mb-4">🤔</div>
          <h1 className="font-pixel text-gold text-lg mb-6">STAGE NOT FOUND</h1>
          <Link href="/arcade" className="pixel-btn">◀ BACK TO ARCADE</Link>
        </div>
      </RetroLayout>
    );
  }

  const accuracy =
    result && result.correct + result.wrong > 0
      ? Math.round((result.correct / (result.correct + result.wrong)) * 100)
      : 0;

  return (
    <RetroLayout>
      <div className="max-w-5xl mx-auto px-3 sm:px-6 lg:px-8 py-5 sm:py-8">
        <div className="flex items-center justify-between flex-wrap gap-3 mb-4">
          <Link href="/arcade" className="font-pixel text-[10px] sm:text-xs text-white hover:text-gold">
            ◀ ARCADE
          </Link>
          <div className="flex items-center gap-2">
            <span className="text-2xl">{chapter.emoji}</span>
            <span className="font-pixel text-gold text-[10px] sm:text-xs">
              STAGE {chapter.number}
            </span>
          </div>
        </div>

        {!result ? (
          <MarioGame
            key={runKey}
            chapterId={chapter.id}
            chapterTitle={chapter.title}
            questions={normalQs}
            bossQuestions={bossQs}
            onComplete={handleComplete}
          />
        ) : (
          <div className="bg-retro-navy border-4 border-gold p-5 sm:p-10 text-center animate-slide-up">
            <div className="text-6xl sm:text-7xl mb-4">
              {result.cleared ? "🏆" : "🎯"}
            </div>
            <h2 className="font-pixel text-gold text-base sm:text-2xl mb-2 pixel-text-shadow">
              {result.cleared ? "STAGE CLEAR!" : "GAME RESULT"}
            </h2>
            <p className="font-thai text-white text-sm sm:text-base mb-6">
              {chapter.title} · {chapter.titleEn}
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-2xl mx-auto mb-8">
              <ResultBox label="SCORE" value={result.score.toString()} color="text-gold" />
              <ResultBox label="CORRECT" value={result.correct.toString()} color="text-grass" />
              <ResultBox label="WRONG" value={result.wrong.toString()} color="text-retro-pink" />
              <ResultBox label="ACCURACY" value={`${accuracy}%`} color="text-coin" />
            </div>

            <div className="font-thai text-white/70 text-xs sm:text-sm mb-6">
              🪙 เหรียญที่เหลือ {result.coins} · 💡 ใช้คำใบ้ {result.hintsUsed} ครั้ง
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={() => {
                  setResult(null);
                  setRunKey((k) => k + 1);
                }}
                className="pixel-btn pixel-btn-green text-[10px] sm:text-xs w-full sm:w-auto"
              >
                🔄 PLAY AGAIN
              </button>
              <Link
                href={`/lesson/${chapter.id}`}
                className="pixel-btn pixel-btn-blue text-[10px] sm:text-xs w-full sm:w-auto text-center"
              >
                📖 เรียนบทเรียน
              </Link>
              <Link href="/arcade" className="pixel-btn text-[10px] sm:text-xs w-full sm:w-auto text-center">
                🎮 OTHER STAGES
              </Link>
            </div>
          </div>
        )}
      </div>
    </RetroLayout>
  );
}

function ResultBox({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="bg-retro-black border-2 border-white/20 p-3 sm:p-4">
      <div className="font-pixel text-[8px] sm:text-[10px] text-white/60 mb-1">{label}</div>
      <div className={`font-pixel text-base sm:text-xl ${color}`}>{value}</div>
    </div>
  );
}

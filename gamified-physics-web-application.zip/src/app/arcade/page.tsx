import Link from "next/link";
import RetroLayout from "@/components/RetroLayout";
import { chapters } from "@/data/chapters";
import { getNormalQuestions, getBossQuestions } from "@/data/questions";

export default function ArcadePage() {
  return (
    <RetroLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {/* Header */}
        <div className="text-center mb-8 sm:mb-12">
          <div className="inline-block mb-4">
            <span className="text-5xl sm:text-6xl animate-bounce-block inline-block">🎮</span>
          </div>
          <h1 className="font-pixel text-gold text-xl sm:text-3xl lg:text-4xl pixel-text-shadow mb-3 sm:mb-4">
            ARCADE MODE
          </h1>
          <p className="font-thai text-white text-sm sm:text-lg max-w-2xl mx-auto pixel-text-shadow-sm mb-2">
            เลือกด่านที่จะตะลุย! ตอบคำถามฟิสิกส์เพื่อเก็บเหรียญและพิชิตบอส
          </p>
          <div className="flex items-center justify-center gap-4 sm:gap-6 font-pixel text-[9px] sm:text-[10px] text-white/90 pixel-text-shadow-sm">
            <span>🪙 +100 COINS</span>
            <span>❤️ 3 HEARTS</span>
            <span>🔥 BOSS FIGHT</span>
          </div>
        </div>

        {/* Chapter Selection Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-12">
          {chapters.map((ch, idx) => {
            const normalCount = getNormalQuestions(ch.id).length;
            const bossCount = getBossQuestions(ch.id).length;
            return (
              <Link
                key={ch.id}
                href={`/arcade/${ch.id}`}
                className="group relative bg-retro-navy border-4 border-white/30 hover:border-gold transition-all hover:-translate-y-1 animate-slide-up overflow-hidden"
                style={{ animationDelay: `${idx * 0.05}s` }}
              >
                {/* Top Banner */}
                <div
                  className="relative p-4 border-b-4 border-white/10"
                  style={{
                    background: `linear-gradient(135deg, ${ch.color}55 0%, ${ch.colorDark}aa 100%)`,
                  }}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-pixel text-white text-[9px] sm:text-[10px] bg-retro-black/50 px-2 py-1">
                      STAGE {ch.number}
                    </span>
                    <span className="text-2xl sm:text-3xl">{ch.emoji}</span>
                  </div>
                  <h2 className="font-thai text-white text-base sm:text-lg font-bold">
                    {ch.title}
                  </h2>
                  <div className="font-thai text-white/70 text-xs italic">
                    {ch.titleEn}
                  </div>
                </div>

                {/* Game Stats */}
                <div className="p-4 sm:p-5">
                  <div className="grid grid-cols-2 gap-2 sm:gap-3 mb-4">
                    <div className="bg-retro-black/50 border-2 border-gold/30 p-2 sm:p-3 text-center">
                      <div className="font-pixel text-gold text-[9px] sm:text-[10px] mb-1">
                        [?] BLOCKS
                      </div>
                      <div className="font-pixel text-white text-lg sm:text-xl">
                        {normalCount}
                      </div>
                    </div>
                    <div className="bg-retro-black/50 border-2 border-retro-pink/30 p-2 sm:p-3 text-center">
                      <div className="font-pixel text-retro-pink text-[9px] sm:text-[10px] mb-1">
                        BOSS Q
                      </div>
                      <div className="font-pixel text-white text-lg sm:text-xl">
                        {bossCount > 0 ? `👹${bossCount}` : "—"}
                      </div>
                    </div>
                  </div>

                  {/* Play button */}
                  <div className="bg-gold border-2 border-retro-black p-2 sm:p-3 text-center font-pixel text-retro-black text-[10px] sm:text-xs group-hover:bg-grass group-hover:text-white transition-colors">
                    ▶ PLAY STAGE {ch.number}
                  </div>
                </div>

                {/* Decorative pixels */}
                <div className="absolute bottom-0 left-0 right-0 h-2 retro-ground-green opacity-50" />
              </Link>
            );
          })}
        </div>

        {/* How to play */}
        <div className="bg-retro-black/70 border-4 border-gold p-5 sm:p-8">
          <h2 className="font-pixel text-gold text-xs sm:text-sm text-center mb-4 sm:mb-6">
            🎮 HOW TO PLAY
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-3xl sm:text-4xl mb-2">🏃</div>
              <div className="font-pixel text-white text-[9px] sm:text-[10px] mb-1">RUN</div>
              <div className="font-thai text-white/70 text-xs sm:text-sm">
                ตัวละครวิ่งอัตโนมัติ ใช้ ← → เพื่อควบคุม
              </div>
            </div>
            <div className="text-center">
              <div className="text-3xl sm:text-4xl mb-2">⬆️</div>
              <div className="font-pixel text-white text-[9px] sm:text-[10px] mb-1">JUMP</div>
              <div className="font-thai text-white/70 text-xs sm:text-sm">
                กด SPACE หรือ ↑ เพื่อกระโดด
              </div>
            </div>
            <div className="text-center">
              <div className="text-3xl sm:text-4xl mb-2">❓</div>
              <div className="font-pixel text-white text-[9px] sm:text-[10px] mb-1">HIT [?]</div>
              <div className="font-thai text-white/70 text-xs sm:text-sm">
                ชนบล็อก ? จากด้านล่างเพื่อตอบคำถาม
              </div>
            </div>
            <div className="text-center">
              <div className="text-3xl sm:text-4xl mb-2">👑</div>
              <div className="font-pixel text-white text-[9px] sm:text-[10px] mb-1">BEAT BOSS</div>
              <div className="font-thai text-white/70 text-xs sm:text-sm">
                พิชิตบอสด้วยข้อสอบยาก 3 ข้อท้ายด่าน!
              </div>
            </div>
            <div className="text-center">
              <div className="text-3xl sm:text-4xl mb-2">💡</div>
              <div className="font-pixel text-white text-[9px] sm:text-[10px] mb-1">USE HINT</div>
              <div className="font-thai text-white/70 text-xs sm:text-sm">
                ติดขัดกดขอคำใบ้ได้ แลกกับ 2 เหรียญ
              </div>
            </div>
          </div>
        </div>
      </div>
    </RetroLayout>
  );
}

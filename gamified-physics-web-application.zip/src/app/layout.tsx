import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Pixel Physics - เตรียมสอบฟิสิกส์ ม.5 สไตล์ 8-bit",
  description:
    "Gamified Exam Preparation สำหรับฟิสิกส์ ม.5 เรียนรู้สรุปเนื้อหา ฝึกข้อสอบแข่งขัน และตะลุยด่านแบบ Mario!",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="th">
      <body className="bg-sky min-h-screen text-retro-black antialiased no-select">
        {children}
      </body>
    </html>
  );
}

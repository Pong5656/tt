import Link from "next/link";
import { notFound } from "next/navigation";
import RetroLayout from "@/components/RetroLayout";
import LessonTimeline from "@/components/LessonTimeline";
import { chapters } from "@/data/chapters";
import { getLessonByChapter } from "@/data/lessons";

export function generateStaticParams() {
  return chapters.map((c) => ({ chapterId: c.id }));
}

export default async function LessonChapterPage({
  params,
}: {
  params: Promise<{ chapterId: string }>;
}) {
  const { chapterId } = await params;
  const chapter = chapters.find((c) => c.id === chapterId);
  const lesson = getLessonByChapter(chapterId);
  if (!chapter || !lesson) notFound();

  return (
    <RetroLayout>
      <div className="max-w-4xl mx-auto px-3 sm:px-6 lg:px-8 py-5 sm:py-8">
        {/* Breadcrumb + header */}
        <div className="flex items-center justify-between flex-wrap gap-3 mb-4">
          <Link href="/lesson" className="font-pixel text-[10px] text-white hover:text-gold">
            ◀ LESSON
          </Link>
          <div className="flex items-center gap-2">
            <Link
              href={`/study/${chapter.id}`}
              className="font-pixel text-[9px] bg-retro-black border-2 border-gold text-gold px-2 py-1 hover:bg-gold hover:text-retro-black"
            >
              📄 สรุปย่อ
            </Link>
            <Link
              href={`/arcade/${chapter.id}`}
              className="font-pixel text-[9px] bg-retro-black border-2 border-retro-pink text-retro-pink px-2 py-1 hover:bg-retro-pink hover:text-white"
            >
              🎮 ตะลุยด่าน
            </Link>
          </div>
        </div>

        <div
          className="border-4 border-gold p-4 sm:p-6 mb-5"
          style={{
            background: `linear-gradient(135deg, ${chapter.color}44 0%, #16213E 100%)`,
          }}
        >
          <div className="flex items-center gap-4">
            <span className="text-4xl sm:text-5xl">{chapter.emoji}</span>
            <div>
              <div className="font-pixel text-gold text-[9px] sm:text-[10px] mb-1">
                LESSON · CHAPTER {chapter.number}
              </div>
              <h1 className="font-thai text-white text-lg sm:text-2xl font-bold">
                {chapter.title}
              </h1>
              <div className="font-thai text-white/65 text-xs sm:text-sm italic">
                {chapter.titleEn}
              </div>
            </div>
          </div>
        </div>

        <LessonTimeline chapter={chapter} lesson={lesson} />
      </div>
    </RetroLayout>
  );
}

import Link from "next/link";
import RetroLayout from "@/components/RetroLayout";
import { chapters } from "@/data/chapters";
import { countLessonSteps, countLessonPractices, getLessonByChapter } from "@/data/lessons";

export default function LessonIndexPage() {
  return (
    <RetroLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        <div className="text-center mb-8 sm:mb-12">
          <div className="inline-block mb-4">
            <span className="text-5xl sm:text-6xl inline-block animate-bounce-block">📖</span>
          </div>
          <h1 className="font-pixel text-gold text-lg sm:text-3xl lg:text-4xl pixel-text-shadow mb-3">
            LESSON MODE
          </h1>
          <p className="font-thai text-white text-sm sm:text-lg max-w-3xl mx-auto pixel-text-shadow-sm mb-3">
            โหมดเรียนรู้ตั้งแต่เริ่มต้น แบบไทม์ไลน์เกม — ค่อยๆ สอนทีละเรื่อง
          </p>
          <div className="flex items-center justify-center gap-2 sm:gap-4 flex-wrap font-pixel text-[8px] sm:text-[10px] text-white/90 pixel-text-shadow-sm">
            <span className="bg-retro-black/60 px-2 py-1">📘 อธิบาย</span>
            <span>▶</span>
            <span className="bg-retro-black/60 px-2 py-1">📐 สูตร</span>
            <span>▶</span>
            <span className="bg-retro-black/60 px-2 py-1">✏️ ตัวอย่าง</span>
            <span>▶</span>
            <span className="bg-retro-black/60 px-2 py-1">❓ ฝึกทำ</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-10">
          {chapters.map((ch, idx) => {
            const lesson = getLessonByChapter(ch.id);
            const steps = countLessonSteps(ch.id);
            const practices = countLessonPractices(ch.id);
            const topics = lesson?.topics.length ?? 0;
            return (
              <Link
                key={ch.id}
                href={`/lesson/${ch.id}`}
                className="group bg-retro-navy border-4 border-white/30 hover:border-gold transition-all hover:-translate-y-1 animate-slide-up"
                style={{ animationDelay: `${idx * 0.05}s` }}
              >
                <div
                  className="p-4 border-b-4 border-white/10"
                  style={{
                    background: `linear-gradient(135deg, ${ch.color}55 0%, ${ch.colorDark}aa 100%)`,
                  }}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-pixel text-white text-[8px] sm:text-[10px] bg-retro-black/60 px-2 py-1">
                      บทที่ {ch.number}
                    </span>
                    <span className="text-3xl">{ch.emoji}</span>
                  </div>
                  <h2 className="font-thai text-white text-base sm:text-lg font-bold">
                    {ch.title}
                  </h2>
                  <div className="font-thai text-white/70 text-xs italic">{ch.titleEn}</div>
                </div>

                <div className="p-4 sm:p-5">
                  <div className="space-y-1.5 mb-4">
                    {lesson?.topics.map((t) => (
                      <div key={t.id} className="flex items-center gap-2">
                        <span className="text-sm">{t.emoji}</span>
                        <span className="font-thai text-white/80 text-xs sm:text-sm truncate">
                          {t.name}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="grid grid-cols-3 gap-2 mb-4">
                    <MiniStat label="TOPICS" value={topics} color="text-mario-blue" />
                    <MiniStat label="STEPS" value={steps} color="text-gold" />
                    <MiniStat label="QUIZ" value={practices} color="text-retro-pink" />
                  </div>

                  <div className="bg-grass border-2 border-retro-black p-2 text-center font-pixel text-white text-[9px] sm:text-[10px] group-hover:bg-gold group-hover:text-retro-black transition-colors">
                    ▶ เริ่มเรียน
                  </div>
                </div>
              </Link>
            );
          })}
        </div>

        <div className="bg-retro-black/70 border-4 border-gold p-5 sm:p-8">
          <h2 className="font-pixel text-gold text-[10px] sm:text-sm text-center mb-5">
            🎓 บทเรียนนี้ทำงานอย่างไร
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <HowCard emoji="📘" title="อธิบายเนื้อหา" desc="เริ่มจากแนวคิดพื้นฐาน เล่าให้เข้าใจเหมือนครูสอนหน้าห้อง" />
            <HowCard emoji="📐" title="แจกแจงสูตร" desc="สรุปสูตรสำคัญ พร้อมอธิบายความหมายของทุกตัวแปร" />
            <HowCard emoji="✏️" title="ดูตัวอย่าง" desc="แสดงวิธีทำทีละขั้นตอนอย่างละเอียด ไม่ข้ามขั้น" />
            <HowCard emoji="❓" title="ลงมือทำ" desc="ตอบถูก = ปลดล็อกเรื่องถัดไป | ตอบผิด = ลองคิดใหม่ได้ไม่จำกัด" />
          </div>
        </div>
      </div>
    </RetroLayout>
  );
}

function MiniStat({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="bg-retro-black/60 border-2 border-white/10 p-2 text-center">
      <div className="font-pixel text-[7px] text-white/50 mb-1">{label}</div>
      <div className={`font-pixel text-sm ${color}`}>{value}</div>
    </div>
  );
}

function HowCard({ emoji, title, desc }: { emoji: string; title: string; desc: string }) {
  return (
    <div className="text-center bg-retro-navy/60 border-2 border-white/15 p-4">
      <div className="text-3xl sm:text-4xl mb-2">{emoji}</div>
      <div className="font-thai text-gold text-sm font-bold mb-1">{title}</div>
      <div className="font-thai text-white/70 text-xs sm:text-sm">{desc}</div>
    </div>
  );
}

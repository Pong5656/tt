import Link from "next/link";
import RetroLayout from "@/components/RetroLayout";
import { chapters } from "@/data/chapters";

export default function HomePage() {
  return (
    <RetroLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-16">
        {/* Hero Section */}
        <div className="text-center mb-12 sm:mb-20 animate-slide-up">
          <div className="inline-block mb-6">
            <div className="question-block w-24 h-24 sm:w-32 sm:h-32 mx-auto animate-bounce-block">
              <span className="text-5xl sm:text-7xl">?</span>
            </div>
          </div>
          <h1 className="font-pixel text-gold text-2xl sm:text-4xl lg:text-5xl pixel-text-shadow mb-4 sm:mb-6">
            PIXEL PHYSICS
          </h1>
          <p className="font-thai text-white text-base sm:text-xl lg:text-2xl max-w-3xl mx-auto mb-8 pixel-text-shadow-sm">
            เตรียมสอบฟิสิกส์ ม.5 แบบ Gamified
            <br />
            เรียนรู้ ฝึกฝน และตะลุยด่านสไตล์ 8-bit!
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/lesson" className="pixel-btn pixel-btn-green text-xs sm:text-sm">
              📖 เริ่มเรียนตั้งแต่ต้น
            </Link>
            <Link href="/arcade" className="pixel-btn text-xs sm:text-sm">
              🎮 เล่นเกม
            </Link>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-12">
          <Link href="/lesson" className="bg-retro-navy border-4 border-mario-blue p-5 sm:p-7 text-center animate-slide-up hover:-translate-y-1 transition-transform">
            <div className="text-4xl sm:text-5xl mb-3">📖</div>
            <h3 className="font-pixel text-mario-blue text-[10px] sm:text-xs mb-2">LESSON MODE</h3>
            <p className="font-thai text-white text-xs sm:text-sm">
              ไทม์ไลน์สอนทีละขั้น
              <br />
              อธิบาย → สูตร → ตัวอย่าง → ฝึก
            </p>
          </Link>

          <Link href="/study" className="bg-retro-navy border-4 border-gold p-5 sm:p-7 text-center animate-slide-up hover:-translate-y-1 transition-transform" style={{ animationDelay: "0.05s" }}>
            <div className="text-4xl sm:text-5xl mb-3">📚</div>
            <h3 className="font-pixel text-gold text-[10px] sm:text-xs mb-2">STUDY MODE</h3>
            <p className="font-thai text-white text-xs sm:text-sm">
              สรุปย่อครบ 7 บท
              <br />
              สูตรสำคัญ + เทคนิคจำ
            </p>
          </Link>

          <Link href="/arcade" className="bg-retro-navy border-4 border-retro-pink p-5 sm:p-7 text-center animate-slide-up hover:-translate-y-1 transition-transform" style={{ animationDelay: "0.1s" }}>
            <div className="text-4xl sm:text-5xl mb-3">🎮</div>
            <h3 className="font-pixel text-retro-pink text-[10px] sm:text-xs mb-2">ARCADE MODE</h3>
            <p className="font-thai text-white text-xs sm:text-sm">
              แพลตฟอร์มเมอร์ 2D
              <br />
              ชนบล็อก [?] ตอบข้อสอบจริง
            </p>
          </Link>

          <Link href="/profile" className="bg-retro-navy border-4 border-grass p-5 sm:p-7 text-center animate-slide-up hover:-translate-y-1 transition-transform" style={{ animationDelay: "0.15s" }}>
            <div className="text-4xl sm:text-5xl mb-3">🏆</div>
            <h3 className="font-pixel text-grass text-[10px] sm:text-xs mb-2">BOSS & STATS</h3>
            <p className="font-thai text-white text-xs sm:text-sm">
              บอส 3 ข้อ/บท จาก สอวน.
              <br />
              A-Level · Entrance
            </p>
          </Link>
        </div>

        {/* Learning flow */}
        <div className="bg-retro-black/60 border-4 border-gold p-5 sm:p-8 mb-12">
          <h2 className="font-pixel text-gold text-[10px] sm:text-sm text-center mb-6">
            🎯 เส้นทางการเรียนรู้
          </h2>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-3 sm:gap-2">
            {[
              { n: "1", t: "เรียนบทเรียน", d: "ไทม์ไลน์ทีละขั้น", c: "border-mario-blue" },
              { n: "2", t: "ทบทวนสรุป", d: "สูตรและเทคนิค", c: "border-gold" },
              { n: "3", t: "ตะลุยด่าน", d: "ฝึกข้อสอบในเกม", c: "border-retro-pink" },
              { n: "4", t: "พิชิตบอส", d: "ข้อสอบระดับแข่งขัน", c: "border-grass" },
            ].map((s, i, arr) => (
              <div key={s.n} className="flex items-center gap-2 sm:gap-1 flex-1">
                <div className={`flex-1 bg-retro-navy border-4 ${s.c} p-3 text-center`}>
                  <div className="font-pixel text-gold text-sm mb-1">{s.n}</div>
                  <div className="font-thai text-white text-xs sm:text-sm font-bold">{s.t}</div>
                  <div className="font-thai text-white/60 text-[10px] sm:text-xs">{s.d}</div>
                </div>
                {i < arr.length - 1 && (
                  <span className="font-pixel text-gold text-sm rotate-90 sm:rotate-0">▶</span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Chapters Preview */}
        <div className="bg-retro-black/50 border-4 border-white/20 p-6 sm:p-8 mb-8">
          <h2 className="font-pixel text-gold text-sm sm:text-lg text-center mb-6 pixel-text-shadow-sm">
            📚 CHAPTERS
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
            {chapters.map((ch) => (
              <Link
                key={ch.id}
                href={`/lesson/${ch.id}`}
                className="bg-retro-navy border-2 border-white/30 hover:border-gold p-3 sm:p-4 text-center transition-all hover:scale-105"
              >
                <div className="text-2xl sm:text-3xl mb-2">{ch.emoji}</div>
                <div className="font-pixel text-gold text-[9px] sm:text-[10px] mb-1">
                  CH {ch.number}
                </div>
                <div className="font-thai text-white text-xs sm:text-sm">
                  {ch.title}
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <div className="inline-block bg-retro-purple border-4 border-gold p-6 sm:p-8 animate-slide-up">
            <p className="font-thai text-white text-base sm:text-lg mb-4">
              พร้อมที่จะเป็น <span className="text-gold font-bold">Pixel Physics Master</span> หรือยัง?
            </p>
            <Link href="/study" className="pixel-btn pixel-btn-green text-xs sm:text-sm">
              ▶ LET&apos;S GO!
            </Link>
          </div>
        </div>
      </div>
    </RetroLayout>
  );
}

"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import RetroLayout from "@/components/RetroLayout";
import { chapters } from "@/data/chapters";

type ChapterStats = {
  bestScore: number;
  attempts: number;
  bestCorrect: number;
  lastPlayed?: number;
};

type TotalStats = {
  totalScore: number;
  totalAttempts: number;
  totalHints?: number;
};

type LessonProgress = {
  index: number;
  maxReached: number;
  xp: number;
  solved: number[];
  total: number;
};

export default function ProfilePage() {
  const [stats, setStats] = useState<Record<string, ChapterStats>>({});
  const [lessonProg, setLessonProg] = useState<Record<string, LessonProgress>>({});
  const [total, setTotal] = useState<TotalStats>({ totalScore: 0, totalAttempts: 0 });
  const [playerName, setPlayerName] = useState("PLAYER 1");
  const [editing, setEditing] = useState(false);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    try {
      const saved: Record<string, ChapterStats> = {};
      const lp: Record<string, LessonProgress> = {};
      chapters.forEach((ch) => {
        const raw = localStorage.getItem(`pixel-physics-${ch.id}`);
        if (raw) saved[ch.id] = JSON.parse(raw);
        const lraw = localStorage.getItem(`pixel-lesson-${ch.id}`);
        if (lraw) lp[ch.id] = JSON.parse(lraw);
      });
      setStats(saved);
      setLessonProg(lp);

      const totalRaw = localStorage.getItem("pixel-physics-total");
      if (totalRaw) setTotal(JSON.parse(totalRaw));

      const name = localStorage.getItem("pixel-physics-name");
      if (name) setPlayerName(name);
    } catch (e) {
      console.error(e);
    }
    setLoaded(true);
  }, []);

  const totalXp = Object.values(lessonProg).reduce((s, l) => s + (l.xp ?? 0), 0);
  const lessonsStarted = Object.keys(lessonProg).length;
  const lessonsFinished = Object.values(lessonProg).filter(
    (l) => l.total > 0 && l.maxReached >= l.total - 1
  ).length;
  const completedChapters = Object.keys(stats).filter((id) => stats[id].attempts > 0);
  const totalBestScore = Object.values(stats).reduce((sum, s) => sum + s.bestScore, 0);
  const totalStars = Object.values(stats).reduce((sum, s) => {
    if (s.bestScore >= 500) return sum + 3;
    if (s.bestScore >= 300) return sum + 2;
    if (s.bestScore > 0) return sum + 1;
    return sum;
  }, 0);

  const saveName = (name: string) => {
    setPlayerName(name);
    try {
      localStorage.setItem("pixel-physics-name", name);
    } catch (e) {
      console.error(e);
    }
    setEditing(false);
  };

  const resetProgress = () => {
    if (!confirm("ล้างข้อมูลความก้าวหน้าทั้งหมด? การกระทำนี้ไม่สามารถย้อนกลับได้")) {
      return;
    }
    try {
      Object.keys(localStorage).forEach((key) => {
        if (key.startsWith("pixel-physics-") || key.startsWith("pixel-lesson-"))
          localStorage.removeItem(key);
      });
      setStats({});
      setLessonProg({});
      setTotal({ totalScore: 0, totalAttempts: 0, totalHints: 0 });
    } catch (e) {
      console.error(e);
    }
  };

  const rankTitle =
    totalBestScore >= 3000
      ? { title: "PHYSICS MASTER", emoji: "👑", color: "text-gold" }
      : totalBestScore >= 1500
      ? { title: "EXPERT", emoji: "🏆", color: "text-grass" }
      : totalBestScore >= 500
      ? { title: "APPRENTICE", emoji: "⭐", color: "text-retro-pink" }
      : { title: "NEWCOMER", emoji: "🌱", color: "text-white" };

  if (!loaded) {
    return (
      <RetroLayout>
        <div className="max-w-5xl mx-auto px-4 py-16 text-center">
          <div className="font-pixel text-gold text-sm animate-blink">LOADING...</div>
        </div>
      </RetroLayout>
    );
  }

  return (
    <RetroLayout>
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10">
        <h1 className="font-pixel text-gold text-xl sm:text-3xl text-center pixel-text-shadow mb-8 sm:mb-12">
          👤 PLAYER PROFILE
        </h1>

        {/* Player Card */}
        <div className="bg-retro-navy border-4 border-gold p-5 sm:p-8 mb-6 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10"
            style={{
              backgroundImage: "repeating-linear-gradient(45deg, #F8B800 0, #F8B800 2px, transparent 2px, transparent 12px)",
            }}
          />
          <div className="relative flex flex-col sm:flex-row items-center gap-5 sm:gap-6">
            {/* Avatar */}
            <div className="flex-shrink-0">
              <div className="w-24 h-24 sm:w-32 sm:h-32 bg-retro-black border-4 border-gold flex items-center justify-center">
                <div className="text-5xl sm:text-6xl">🧑‍🚀</div>
              </div>
            </div>

            {/* Info */}
            <div className="flex-1 text-center sm:text-left">
              {editing ? (
                <div className="mb-2">
                  <input
                    type="text"
                    defaultValue={playerName}
                    maxLength={20}
                    autoFocus
                    onBlur={(e) => saveName(e.target.value || "PLAYER 1")}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") saveName((e.target as HTMLInputElement).value || "PLAYER 1");
                    }}
                    className="font-pixel text-gold text-lg sm:text-xl bg-retro-black border-2 border-gold px-3 py-2 text-center sm:text-left w-full max-w-xs"
                  />
                </div>
              ) : (
                <button
                  onClick={() => setEditing(true)}
                  className="font-pixel text-gold text-lg sm:text-2xl mb-1 hover:text-white group"
                >
                  {playerName}
                  <span className="text-xs ml-2 text-white/50 group-hover:text-gold">✎</span>
                </button>
              )}
              <div className="flex items-center justify-center sm:justify-start gap-2 mb-2">
                <span className="text-2xl">{rankTitle.emoji}</span>
                <span className={`font-pixel text-[10px] sm:text-xs ${rankTitle.color}`}>
                  {rankTitle.title}
                </span>
              </div>
              <div className="font-thai text-white/70 text-xs sm:text-sm">
                เล่นทั้งหมด {total.totalAttempts} ครั้ง | สะสม {total.totalScore.toLocaleString()} คะแนน
              </div>
            </div>

            {/* Stars */}
            <div className="text-center">
              <div className="font-pixel text-[10px] sm:text-xs text-gold mb-1">TOTAL STARS</div>
              <div className="text-3xl sm:text-4xl font-pixel text-white">
                {totalStars}
                <span className="text-gold ml-1">★</span>
              </div>
              <div className="font-thai text-white/60 text-xs">
                / {chapters.length * 3}
              </div>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 mb-8">
          <StatBox label="BEST SCORE" value={totalBestScore.toLocaleString()} color="text-gold" icon="🏅" />
          <StatBox label="LESSON XP" value={totalXp.toString()} color="text-mario-blue" icon="📖" />
          <StatBox label="LESSON DONE" value={`${lessonsFinished}/${chapters.length}`} color="text-grass" icon="🎓" />
          <StatBox label="STAGES" value={`${completedChapters.length}/${chapters.length}`} color="text-retro-pink" icon="🎮" />
          <StatBox label="HINTS USED" value={(total.totalHints ?? 0).toString()} color="text-coin" icon="💡" />
          <StatBox label="STARS" value={`${totalStars}★`} color="text-coin" icon="⭐" />
        </div>

        {/* Lesson Progress */}
        <div className="bg-retro-navy border-4 border-mario-blue p-5 sm:p-6 mb-6">
          <h2 className="font-pixel text-mario-blue text-xs sm:text-sm mb-4 sm:mb-6">
            📖 LESSON PROGRESS
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {chapters.map((ch) => {
              const lp = lessonProg[ch.id];
              const pct = lp && lp.total ? Math.round(((lp.maxReached + 1) / lp.total) * 100) : 0;
              return (
                <Link
                  key={ch.id}
                  href={`/lesson/${ch.id}`}
                  className="flex items-center gap-3 bg-retro-black/40 border-2 border-white/10 hover:border-mario-blue p-3 transition-all"
                >
                  <span className="text-xl">{ch.emoji}</span>
                  <div className="flex-1 min-w-0">
                    <div className="font-thai text-white text-xs sm:text-sm font-bold truncate mb-1">
                      บทที่ {ch.number} · {ch.title}
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-retro-black border border-white/20 h-2">
                        <div className="h-full bg-mario-blue" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="font-pixel text-[8px] text-white/60 w-10 text-right">
                        {pct}%
                      </span>
                    </div>
                  </div>
                  {lp?.xp ? (
                    <span className="font-pixel text-[8px] text-coin shrink-0">
                      {lp.xp} XP
                    </span>
                  ) : (
                    <span className="font-pixel text-[8px] text-white/40 shrink-0">START</span>
                  )}
                </Link>
              );
            })}
          </div>
          {lessonsStarted === 0 && (
            <p className="mt-4 text-center font-thai text-white/60 text-xs sm:text-sm">
              ยังไม่ได้เริ่มเรียนเลย — ลองเริ่มจากบทที่ 11 ดูสิ!
            </p>
          )}
        </div>

        {/* Chapters Progress */}
        <div className="bg-retro-navy border-4 border-white/30 p-5 sm:p-6 mb-6">
          <h2 className="font-pixel text-gold text-xs sm:text-sm mb-4 sm:mb-6">
            📊 CHAPTER PROGRESS
          </h2>
          <div className="space-y-3">
            {chapters.map((ch) => {
              const s = stats[ch.id];
              const stars = !s ? 0 : s.bestScore >= 500 ? 3 : s.bestScore >= 300 ? 2 : s.bestScore > 0 ? 1 : 0;
              return (
                <Link
                  key={ch.id}
                  href={`/arcade/${ch.id}`}
                  className="flex items-center gap-3 sm:gap-4 bg-retro-black/40 border-2 border-white/10 hover:border-gold p-3 sm:p-4 transition-all group"
                >
                  <div
                    className="w-10 h-10 sm:w-12 sm:h-12 flex-shrink-0 flex items-center justify-center text-xl sm:text-2xl border-2"
                    style={{ backgroundColor: `${ch.color}33`, borderColor: `${ch.color}88` }}
                  >
                    {ch.emoji}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-pixel text-[9px] sm:text-[10px] text-gold">CH{ch.number}</span>
                      <span className="font-thai text-white text-xs sm:text-sm font-bold truncate">
                        {ch.title}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-retro-black border border-white/20 h-2 overflow-hidden">
                        <div
                          className="h-full bg-grass"
                          style={{ width: `${(stars / 3) * 100}%` }}
                        />
                      </div>
                      <span className="font-pixel text-[9px] sm:text-[10px] text-white/60">
                        {stars}/3★
                      </span>
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    {s ? (
                      <>
                        <div className="font-pixel text-[9px] sm:text-[10px] text-gold">
                          {s.bestScore}
                        </div>
                        <div className="font-thai text-white/50 text-[10px] sm:text-xs">
                          {s.attempts}x played
                        </div>
                      </>
                    ) : (
                      <span className="font-pixel text-[9px] sm:text-[10px] text-white/40 group-hover:text-gold">
                        PLAY ▶
                      </span>
                    )}
                  </div>
                </Link>
              );
            })}
          </div>
        </div>

        {/* Achievements */}
        <div className="bg-retro-navy border-4 border-white/30 p-5 sm:p-6 mb-6">
          <h2 className="font-pixel text-gold text-xs sm:text-sm mb-4 sm:mb-6">
            🏆 ACHIEVEMENTS
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            <Achievement
              unlocked={completedChapters.length >= 1}
              emoji="🎯"
              title="FIRST WIN"
              desc="ผ่านด่านแรก"
            />
            <Achievement
              unlocked={completedChapters.length >= 4}
              emoji="⚔️"
              title="HALF WAY"
              desc="ผ่าน 4 ด่าน"
            />
            <Achievement
              unlocked={completedChapters.length >= 7}
              emoji="👑"
              title="CHAMPION"
              desc="ผ่านทุกด่าน"
            />
            <Achievement
              unlocked={totalBestScore >= 1000}
              emoji="💰"
              title="RICH"
              desc="สะสม 1000 คะแนน"
            />
            <Achievement
              unlocked={totalBestScore >= 3000}
              emoji="💎"
              title="MASTER"
              desc="สะสม 3000 คะแนน"
            />
            <Achievement
              unlocked={total.totalAttempts >= 10}
              emoji="🔥"
              title="GRINDER"
              desc="เล่น 10 ครั้ง"
            />
            <Achievement
              unlocked={totalStars >= 10}
              emoji="🌟"
              title="STAR GAZER"
              desc="เก็บ 10 ดาว"
            />
            <Achievement
              unlocked={totalStars >= 21}
              emoji="🌌"
              title="GALAXY"
              desc="เก็บทุกดาว"
            />
            <Achievement
              unlocked={lessonsStarted >= 1}
              emoji="📖"
              title="STUDENT"
              desc="เริ่มเรียนบทแรก"
            />
            <Achievement
              unlocked={lessonsFinished >= 3}
              emoji="🎓"
              title="SCHOLAR"
              desc="เรียนจบ 3 บท"
            />
            <Achievement
              unlocked={lessonsFinished >= 7}
              emoji="🧠"
              title="PROFESSOR"
              desc="เรียนจบทุกบท"
            />
            <Achievement
              unlocked={totalXp >= 200}
              emoji="✨"
              title="XP HUNTER"
              desc="สะสม 200 XP"
            />
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-3">
          <Link href="/arcade" className="pixel-btn pixel-btn-green text-center text-[10px] sm:text-xs">
            🎮 PLAY MORE
          </Link>
          <Link href="/lesson" className="pixel-btn pixel-btn-blue text-center text-[10px] sm:text-xs">
            📖 LESSON
          </Link>
          <Link href="/study" className="pixel-btn text-center text-[10px] sm:text-xs">
            📚 STUDY
          </Link>
          <button
            onClick={resetProgress}
            className="pixel-btn pixel-btn-red text-[10px] sm:text-xs"
          >
            🗑 RESET PROGRESS
          </button>
        </div>
      </div>
    </RetroLayout>
  );
}

function StatBox({ label, value, color, icon }: { label: string; value: string; color: string; icon: string }) {
  return (
    <div className="bg-retro-navy border-4 border-white/30 p-3 sm:p-4 text-center">
      <div className="text-2xl sm:text-3xl mb-1">{icon}</div>
      <div className="font-pixel text-[9px] sm:text-[10px] text-white/60 mb-1">{label}</div>
      <div className={`font-pixel text-sm sm:text-lg ${color}`}>{value}</div>
    </div>
  );
}

function Achievement({
  unlocked,
  emoji,
  title,
  desc,
}: {
  unlocked: boolean;
  emoji: string;
  title: string;
  desc: string;
}) {
  return (
    <div
      className={`border-2 p-3 text-center transition-all ${
        unlocked
          ? "bg-gold/20 border-gold"
          : "bg-retro-black/40 border-white/10 opacity-50 grayscale"
      }`}
    >
      <div className="text-2xl sm:text-3xl mb-1">{unlocked ? emoji : "🔒"}</div>
      <div className="font-pixel text-[8px] sm:text-[9px] text-gold mb-1">{title}</div>
      <div className="font-thai text-white/80 text-[10px] sm:text-xs">{desc}</div>
    </div>
  );
}

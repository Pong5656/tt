import Link from "next/link";
import RetroLayout from "@/components/RetroLayout";
import { chapters } from "@/data/chapters";
import { notFound } from "next/navigation";

export function generateStaticParams() {
  return chapters.map((c) => ({ chapterId: c.id }));
}

export default async function ChapterDetailPage({
  params,
}: {
  params: Promise<{ chapterId: string }>;
}) {
  const { chapterId } = await params;
  const chapter = chapters.find((c) => c.id === chapterId);
  if (!chapter) notFound();

  const prev = chapters.find((c) => c.number === chapter.number - 1);
  const next = chapters.find((c) => c.number === chapter.number + 1);

  return (
    <RetroLayout>
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10">
        {/* Breadcrumb */}
        <nav className="font-pixel text-[9px] sm:text-[10px] text-white/60 mb-4">
          <Link href="/study" className="hover:text-gold">STUDY</Link>
          <span className="mx-2">▶</span>
          <span className="text-gold">CH {chapter.number}</span>
        </nav>

        {/* Chapter Header */}
        <div
          className="relative bg-retro-navy border-4 border-gold p-5 sm:p-8 mb-6 overflow-hidden"
          style={{ background: `linear-gradient(135deg, ${chapter.color}33 0%, #16213E 100%)` }}
        >
          <div className="absolute top-3 right-3 sm:top-4 sm:right-4 font-pixel text-gold text-lg sm:text-2xl opacity-30">
            CH{chapter.number}
          </div>
          <div className="flex items-start gap-4">
            <div className="text-5xl sm:text-6xl">{chapter.emoji}</div>
            <div className="flex-1">
              <div className="font-pixel text-gold text-[10px] sm:text-xs mb-2">
                CHAPTER {chapter.number}
              </div>
              <h1 className="font-thai text-white text-xl sm:text-3xl font-bold mb-1">
                {chapter.title}
              </h1>
              <div className="font-thai text-white/70 text-sm sm:text-base italic">
                {chapter.titleEn}
              </div>
            </div>
          </div>
        </div>

        {/* Summary Section */}
        <section className="bg-retro-navy border-4 border-white/30 p-5 sm:p-6 mb-6">
          <h2 className="font-pixel text-gold text-xs sm:text-sm mb-4 flex items-center gap-2">
            <span className="question-block w-6 h-6 sm:w-8 sm:h-8 text-sm sm:text-xl" style={{ boxShadow: "inset -2px -2px 0 0 #A85000, inset 2px 2px 0 0 #FFC850, 0 0 0 2px #1A1A2E" }}></span>
            SUMMARY
          </h2>
          <p className="font-thai text-white text-sm sm:text-base leading-relaxed">
            {chapter.summary}
          </p>
        </section>

        {/* Key Topics */}
        <section className="bg-retro-navy border-4 border-white/30 p-5 sm:p-6 mb-6">
          <h2 className="font-pixel text-grass text-xs sm:text-sm mb-4">📋 KEY TOPICS</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3">
            {chapter.keyTopics.map((topic, i) => (
              <div
                key={i}
                className="flex items-center gap-3 bg-retro-black/40 border-2 border-grass/30 p-3"
              >
                <div className="brick-block w-8 h-8 sm:w-10 sm:h-10 flex-shrink-0 flex items-center justify-center font-pixel text-white text-[10px] sm:text-xs">
                  {i + 1}
                </div>
                <div className="font-thai text-white text-xs sm:text-sm">{topic}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Formulas */}
        <section className="bg-retro-navy border-4 border-white/30 p-5 sm:p-6 mb-6">
          <h2 className="font-pixel text-gold text-xs sm:text-sm mb-4">
            📐 IMPORTANT FORMULAS
          </h2>
          <div className="space-y-3 sm:space-y-4">
            {chapter.formulas.map((f, i) => (
              <div
                key={i}
                className="bg-retro-black/60 border-2 border-gold/50 p-4 sm:p-5"
              >
                <div className="flex items-start gap-3">
                  <div className="font-pixel text-retro-pink text-[10px] sm:text-xs mt-1 flex-shrink-0">
                    F{i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-thai text-gold text-sm sm:text-base font-bold mb-2">
                      {f.name}
                    </div>
                    <div className="bg-retro-black border-2 border-gold/30 p-3 sm:p-4 mb-2 font-mono text-white text-base sm:text-lg lg:text-xl text-center tracking-wide">
                      {f.formula}
                    </div>
                    <div className="font-thai text-white/80 text-xs sm:text-sm">
                      {f.description}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Tips */}
        <section className="bg-retro-purple/40 border-4 border-retro-purple p-5 sm:p-6 mb-6">
          <h2 className="font-pixel text-retro-pink text-xs sm:text-sm mb-4">💡 EXAM TIPS</h2>
          <div className="space-y-2 sm:space-y-3">
            {chapter.tips.map((tip, i) => (
              <div key={i} className="flex items-start gap-3">
                <span className="text-retro-pink text-xl">★</span>
                <p className="font-thai text-white text-sm sm:text-base leading-relaxed flex-1">
                  {tip}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 sm:gap-4 mb-6">
          <div className="flex flex-col sm:flex-row gap-3">
            <Link
              href={`/lesson/${chapter.id}`}
              className="pixel-btn pixel-btn-blue text-center text-[10px] sm:text-xs"
            >
              📖 เรียนแบบไทม์ไลน์
            </Link>
            <Link
              href={`/arcade/${chapter.id}`}
              className="pixel-btn pixel-btn-red text-center text-[10px] sm:text-xs"
            >
              🎮 ท้าทายใน ARCADE
            </Link>
          </div>
          <div className="flex gap-2 sm:gap-3">
            {prev && (
              <Link
                href={`/study/${prev.id}`}
                className="pixel-btn pixel-btn-blue text-[10px] sm:text-xs"
              >
                ◀ CH{prev.number}
              </Link>
            )}
            <Link href="/study" className="pixel-btn text-[10px] sm:text-xs">
              📚 ALL
            </Link>
            {next && (
              <Link
                href={`/study/${next.id}`}
                className="pixel-btn pixel-btn-green text-[10px] sm:text-xs"
              >
                CH{next.number} ▶
              </Link>
            )}
          </div>
        </div>
      </div>
    </RetroLayout>
  );
}

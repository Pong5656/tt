import Link from "next/link";
import RetroLayout from "@/components/RetroLayout";
import { chapters } from "@/data/chapters";

export default function StudyPage() {
  return (
    <RetroLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {/* Header */}
        <div className="text-center mb-8 sm:mb-12">
          <h1 className="font-pixel text-gold text-xl sm:text-3xl lg:text-4xl pixel-text-shadow mb-3 sm:mb-4">
            📚 STUDY MODULES
          </h1>
          <p className="font-thai text-white text-sm sm:text-lg max-w-2xl mx-auto pixel-text-shadow-sm">
            เลือกบทเรียนที่ต้องการศึกษา - สรุปเนื้อหา สูตร และเทคนิคครบถ้วน
          </p>
        </div>

        {/* Chapters Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {chapters.map((ch, idx) => (
            <Link
              key={ch.id}
              href={`/study/${ch.id}`}
              className="group relative bg-retro-navy border-4 border-white/30 hover:border-gold transition-all hover:-translate-y-1 animate-slide-up"
              style={{ animationDelay: `${idx * 0.05}s` }}
            >
              {/* Chapter Number Badge */}
              <div className="absolute -top-3 -left-3 bg-gold border-2 border-retro-black px-2 py-1 font-pixel text-[10px] text-retro-black">
                CH {ch.number}
              </div>

              {/* Header with emoji */}
              <div
                className="p-4 sm:p-6 border-b-4 border-white/10"
                style={{ backgroundColor: `${ch.color}22` }}
              >
                <div className="flex items-center gap-3 sm:gap-4">
                  <div className="text-4xl sm:text-5xl">{ch.emoji}</div>
                  <div className="flex-1 min-w-0">
                    <div className="font-pixel text-gold text-[10px] sm:text-xs mb-1 truncate">
                      CHAPTER {ch.number}
                    </div>
                    <h2 className="font-thai text-white text-base sm:text-lg font-bold truncate">
                      {ch.title}
                    </h2>
                    <div className="font-thai text-white/60 text-xs sm:text-sm truncate">
                      {ch.titleEn}
                    </div>
                  </div>
                </div>
              </div>

              {/* Summary */}
              <div className="p-4 sm:p-6">
                <p className="font-thai text-white/80 text-xs sm:text-sm leading-relaxed line-clamp-3 mb-4">
                  {ch.summary}
                </p>

                {/* Key Topics Preview */}
                <div className="space-y-1 mb-4">
                  {ch.keyTopics.slice(0, 3).map((topic, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <span className="text-gold mt-0.5">▸</span>
                      <span className="font-thai text-white/70 text-xs sm:text-sm line-clamp-1">
                        {topic}
                      </span>
                    </div>
                  ))}
                  {ch.keyTopics.length > 3 && (
                    <div className="font-thai text-white/50 text-xs">
                      +{ch.keyTopics.length - 3} หัวข้ออื่น
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between pt-3 border-t-2 border-white/10">
                  <div className="font-pixel text-[9px] sm:text-[10px] text-grass">
                    {ch.formulas.length} FORMULAS
                  </div>
                  <div className="font-pixel text-[9px] sm:text-[10px] text-gold group-hover:translate-x-1 transition-transform">
                    READ ▶
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Tip Box */}
        <div className="mt-8 sm:mt-12 bg-retro-purple/40 border-4 border-retro-purple p-4 sm:p-6 text-center">
          <div className="text-3xl sm:text-4xl mb-2">💡</div>
          <p className="font-thai text-white text-sm sm:text-base mb-3">
            <span className="font-bold text-gold">TIP:</span> หน้านี้คือ &quot;สรุปย่อ&quot; สำหรับทบทวนเร็วๆ
            ถ้าอยากเรียนใหม่ตั้งแต่ต้นแบบมีครูสอน ให้ไปที่ <span className="text-mario-blue font-bold">Lesson Mode</span>
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link href="/lesson" className="pixel-btn pixel-btn-blue text-[10px] sm:text-xs">
              📖 LESSON MODE
            </Link>
            <Link href="/arcade" className="pixel-btn pixel-btn-red text-[10px] sm:text-xs">
              🎮 ARCADE MODE
            </Link>
          </div>
        </div>
      </div>
    </RetroLayout>
  );
}

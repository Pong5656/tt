"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import type { ChapterLesson, LessonStep } from "@/data/lessons";
import type { Chapter } from "@/data/chapters";

type FlatStep = {
  step: LessonStep;
  topicId: string;
  topicName: string;
  topicEmoji: string;
  topicIndex: number;
  indexInTopic: number;
};

export default function LessonTimeline({
  chapter,
  lesson,
}: {
  chapter: Chapter;
  lesson: ChapterLesson;
}) {
  const flat: FlatStep[] = useMemo(() => {
    const out: FlatStep[] = [];
    lesson.topics.forEach((topic, ti) => {
      topic.steps.forEach((step, si) => {
        out.push({
          step,
          topicId: topic.id,
          topicName: topic.name,
          topicEmoji: topic.emoji,
          topicIndex: ti,
          indexInTopic: si,
        });
      });
    });
    return out;
  }, [lesson]);

  const [index, setIndex] = useState(0);
  const [maxReached, setMaxReached] = useState(0);
  const [xp, setXp] = useState(0);
  const [loaded, setLoaded] = useState(false);

  // practice state
  const [selected, setSelected] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [solvedSet, setSolvedSet] = useState<Set<number>>(new Set());

  const topRef = useRef<HTMLDivElement | null>(null);
  const storageKey = `pixel-lesson-${chapter.id}`;

  /* load progress */
  useEffect(() => {
    try {
      const raw = localStorage.getItem(storageKey);
      if (raw) {
        const d = JSON.parse(raw);
        const safeIdx = Math.min(d.index ?? 0, flat.length - 1);
        setIndex(safeIdx);
        setMaxReached(Math.min(d.maxReached ?? safeIdx, flat.length - 1));
        setXp(d.xp ?? 0);
        setSolvedSet(new Set<number>(d.solved ?? []));
      }
    } catch {
      /* ignore */
    }
    setLoaded(true);
  }, [storageKey, flat.length]);

  /* save progress */
  useEffect(() => {
    if (!loaded) return;
    try {
      localStorage.setItem(
        storageKey,
        JSON.stringify({
          index,
          maxReached,
          xp,
          solved: Array.from(solvedSet),
          total: flat.length,
          updated: Date.now(),
        })
      );
    } catch {
      /* ignore */
    }
  }, [index, maxReached, xp, solvedSet, loaded, storageKey, flat.length]);

  const current = flat[index];
  const isPractice = current?.step.kind === "practice";
  const isSolved = solvedSet.has(index);
  const canAdvance = !isPractice || isSolved;
  const progress = flat.length ? ((index + 1) / flat.length) * 100 : 0;

  const resetPracticeState = () => {
    setSelected(null);
    setAnswered(false);
    setShowHint(false);
    setAttempts(0);
  };

  const goTo = (i: number) => {
    if (i < 0 || i >= flat.length) return;
    if (i > maxReached) return;
    setIndex(i);
    resetPracticeState();
    topRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const next = () => {
    if (!canAdvance) return;
    const ni = Math.min(index + 1, flat.length - 1);
    setIndex(ni);
    setMaxReached((m) => Math.max(m, ni));
    resetPracticeState();
    topRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const prev = () => goTo(index - 1);

  const handleSelect = (i: number) => {
    if (answered || isSolved) return;
    const step = current.step;
    if (step.kind !== "practice") return;
    setSelected(i);
    setAnswered(true);
    setAttempts((a) => a + 1);
    if (i === step.correctIndex) {
      const gained = showHint ? 5 : attempts === 0 ? 10 : 7;
      setXp((x) => x + gained);
      setSolvedSet((s) => new Set(s).add(index));
    }
  };

  const retry = () => {
    setSelected(null);
    setAnswered(false);
  };

  if (!loaded) {
    return (
      <div className="text-center py-20 font-pixel text-gold text-sm animate-blink">
        LOADING LESSON...
      </div>
    );
  }

  if (!current) {
    return (
      <div className="text-center py-20 font-thai text-white">
        ยังไม่มีเนื้อหาบทเรียนสำหรับบทนี้
      </div>
    );
  }

  const allDone = index === flat.length - 1 && canAdvance;

  return (
    <div ref={topRef}>
      {/* ── Top status bar ── */}
      <div className="bg-retro-black border-4 border-gold p-3 mb-4 sticky top-16 sm:top-20 z-30">
        <div className="flex items-center justify-between flex-wrap gap-2 mb-2">
          <div className="flex items-center gap-2">
            <span className="text-xl">{current.topicEmoji}</span>
            <span className="font-thai text-gold text-xs sm:text-sm font-bold">
              {current.topicName}
            </span>
          </div>
          <div className="flex items-center gap-3 font-pixel text-[8px] sm:text-[10px]">
            <span className="text-coin">⭐ XP {xp}</span>
            <span className="text-white">
              {index + 1}/{flat.length}
            </span>
          </div>
        </div>
        {/* Progress bar */}
        <div className="h-3 bg-retro-navy border-2 border-white/20 relative overflow-hidden">
          <div
            className="h-full bg-grass transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
          <div
            className="absolute top-0 h-full w-1 bg-white/60"
            style={{ left: `${progress}%` }}
          />
        </div>
      </div>

      {/* ── Timeline node map ── */}
      <div className="bg-retro-navy/70 border-4 border-white/20 p-3 mb-5 overflow-x-auto">
        <div className="flex items-center gap-1 min-w-max">
          {flat.map((f, i) => {
            const locked = i > maxReached;
            const done = i < index || (i === index && canAdvance);
            const isNow = i === index;
            const kind = f.step.kind;
            const icon =
              kind === "concept" ? "📘"
              : kind === "formula" ? "📐"
              : kind === "example" ? "✏️"
              : "❓";
            return (
              <div key={i} className="flex items-center">
                <button
                  onClick={() => goTo(i)}
                  disabled={locked}
                  title={`${f.topicName} · ${kind}`}
                  className={`w-8 h-8 sm:w-9 sm:h-9 flex items-center justify-center text-sm border-2 transition-all shrink-0 ${
                    isNow
                      ? "border-gold bg-gold/30 scale-110"
                      : done
                      ? "border-grass bg-grass/20"
                      : locked
                      ? "border-white/10 bg-retro-black/60 opacity-40 cursor-not-allowed"
                      : "border-white/30 bg-retro-black/40 hover:border-gold"
                  }`}
                >
                  {locked ? "🔒" : icon}
                </button>
                {i < flat.length - 1 && (
                  <div
                    className={`w-3 sm:w-4 h-1 ${
                      i < maxReached ? "bg-grass" : "bg-white/15"
                    }`}
                  />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* ── Step card ── */}
      <StepCard
        step={current.step}
        chapterColor={chapter.color}
        practice={{
          selected,
          answered,
          showHint,
          isSolved,
          attempts,
          onSelect: handleSelect,
          onHint: () => setShowHint(true),
          onRetry: retry,
        }}
      />

      {/* ── Navigation ── */}
      <div className="mt-5 flex items-center justify-between gap-3 flex-wrap">
        <button
          onClick={prev}
          disabled={index === 0}
          className={`pixel-btn text-[10px] sm:text-xs ${
            index === 0 ? "opacity-40 pointer-events-none" : ""
          }`}
        >
          ◀ ย้อนกลับ
        </button>

        {allDone ? (
          <div className="flex flex-col sm:flex-row gap-3 items-center">
            <div className="font-pixel text-gold text-[10px] animate-blink">
              🎉 LESSON COMPLETE!
            </div>
            <Link
              href={`/arcade/${chapter.id}`}
              className="pixel-btn pixel-btn-red text-[10px] sm:text-xs text-center"
            >
              🎮 ไปตะลุยด่าน
            </Link>
          </div>
        ) : (
          <button
            onClick={next}
            disabled={!canAdvance}
            className={`pixel-btn text-[10px] sm:text-xs ${
              canAdvance ? "pixel-btn-green" : "opacity-50 pointer-events-none"
            }`}
          >
            {canAdvance ? "หน้าถัดไป ▶" : "🔒 ตอบให้ถูกก่อน"}
          </button>
        )}
      </div>

      {isPractice && !isSolved && (
        <p className="mt-3 text-center font-thai text-white/60 text-xs sm:text-sm">
          ⚠️ ต้องตอบข้อนี้ให้ถูกก่อน จึงจะไปเรียนเรื่องถัดไปได้
        </p>
      )}
    </div>
  );
}

/* ══════════════════════════════════════════ */

function StepCard({
  step,
  chapterColor,
  practice,
}: {
  step: LessonStep;
  chapterColor: string;
  practice: {
    selected: number | null;
    answered: boolean;
    showHint: boolean;
    isSolved: boolean;
    attempts: number;
    onSelect: (i: number) => void;
    onHint: () => void;
    onRetry: () => void;
  };
}) {
  if (step.kind === "concept") {
    return (
      <section
        className="bg-retro-navy border-4 border-white/30 animate-slide-up"
        style={{ borderTopColor: chapterColor, borderTopWidth: 8 }}
      >
        <div className="bg-retro-black/60 px-4 sm:px-6 py-3 border-b-2 border-white/10 flex items-center gap-3">
          <span className="font-pixel text-[9px] sm:text-[10px] bg-mario-blue text-white px-2 py-1">
            📘 CONCEPT
          </span>
          <h2 className="font-thai text-white text-base sm:text-xl font-bold">
            {step.title}
          </h2>
        </div>
        <div className="p-4 sm:p-7 space-y-3 sm:space-y-4">
          {step.body.map((para, i) => (
            <p
              key={i}
              className="font-thai text-white/90 text-sm sm:text-lg leading-relaxed sm:leading-loose"
            >
              {para}
            </p>
          ))}
        </div>
      </section>
    );
  }

  if (step.kind === "formula") {
    return (
      <section className="bg-retro-navy border-4 border-gold animate-slide-up">
        <div className="bg-retro-black/60 px-4 sm:px-6 py-3 border-b-2 border-gold/30 flex items-center gap-3">
          <span className="font-pixel text-[9px] sm:text-[10px] bg-gold text-retro-black px-2 py-1">
            📐 FORMULA
          </span>
          <h2 className="font-thai text-gold text-base sm:text-xl font-bold">
            {step.title}
          </h2>
        </div>
        <div className="p-4 sm:p-7">
          <div className="bg-retro-black border-4 border-gold/50 p-4 sm:p-8 mb-5 text-center">
            <div className="font-mono text-white text-base sm:text-2xl lg:text-3xl tracking-wide break-words">
              {step.formula}
            </div>
          </div>
          <div className="space-y-2">
            {step.vars.map((v, i) => (
              <div
                key={i}
                className="flex items-start gap-3 bg-retro-black/40 border-2 border-white/10 p-2.5 sm:p-3"
              >
                <span className="font-mono text-gold text-sm sm:text-base font-bold min-w-[70px] sm:min-w-[110px]">
                  {v.sym}
                </span>
                <span className="font-thai text-white/85 text-xs sm:text-base flex-1">
                  {v.desc}
                </span>
              </div>
            ))}
          </div>
          {step.note && (
            <div className="mt-4 bg-retro-purple/30 border-l-4 border-retro-pink p-3 sm:p-4">
              <p className="font-thai text-white text-xs sm:text-base leading-relaxed">
                {step.note}
              </p>
            </div>
          )}
        </div>
      </section>
    );
  }

  if (step.kind === "example") {
    return (
      <section className="bg-retro-navy border-4 border-mario-blue animate-slide-up">
        <div className="bg-retro-black/60 px-4 sm:px-6 py-3 border-b-2 border-mario-blue/40 flex items-center gap-3">
          <span className="font-pixel text-[9px] sm:text-[10px] bg-mario-blue text-white px-2 py-1">
            ✏️ EXAMPLE
          </span>
          <h2 className="font-thai text-white text-base sm:text-xl font-bold">
            {step.title}
          </h2>
        </div>
        <div className="p-4 sm:p-7">
          <div className="bg-retro-black/60 border-2 border-white/20 p-3 sm:p-5 mb-5">
            <div className="font-pixel text-gold text-[9px] mb-2">โจทย์</div>
            <p className="font-thai text-white text-sm sm:text-lg leading-relaxed">
              {step.problem}
            </p>
          </div>
          <div className="font-pixel text-grass text-[9px] mb-3">วิธีทำ</div>
          <ol className="space-y-2 mb-5">
            {step.steps.map((s, i) => (
              <li key={i} className="flex items-start gap-3">
                <span className="font-pixel text-[9px] bg-grass text-white w-6 h-6 flex items-center justify-center shrink-0 mt-0.5">
                  {i + 1}
                </span>
                <span className="font-thai text-white/90 text-xs sm:text-base leading-relaxed flex-1 font-mono-numeric">
                  {s}
                </span>
              </li>
            ))}
          </ol>
          <div className="bg-grass/20 border-4 border-grass p-3 sm:p-4">
            <div className="font-pixel text-grass text-[9px] mb-2">✅ คำตอบ</div>
            <p className="font-thai text-white text-sm sm:text-lg font-bold">
              {step.answer}
            </p>
          </div>
        </div>
      </section>
    );
  }

  // ── PRACTICE ──
  const { selected, answered, showHint, isSolved, attempts, onSelect, onHint, onRetry } =
    practice;
  const correct = selected === step.correctIndex;

  return (
    <section className="bg-retro-navy border-4 border-retro-pink animate-slide-up">
      <div className="bg-retro-black/70 px-4 sm:px-6 py-3 border-b-2 border-retro-pink/40 flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-3">
          <span className="font-pixel text-[9px] sm:text-[10px] bg-retro-pink text-white px-2 py-1">
            ❓ PRACTICE
          </span>
          <h2 className="font-thai text-white text-base sm:text-xl font-bold">
            {step.title}
          </h2>
        </div>
        {isSolved && (
          <span className="font-pixel text-[9px] text-grass">✅ SOLVED</span>
        )}
        {attempts > 0 && !isSolved && (
          <span className="font-pixel text-[9px] text-white/50">
            ลองแล้ว {attempts} ครั้ง
          </span>
        )}
      </div>

      <div className="p-4 sm:p-7">
        <p className="font-thai text-white text-sm sm:text-lg leading-relaxed mb-5">
          {step.question}
        </p>

        {/* Hint */}
        {!isSolved && (
          <div className="mb-5">
            {!showHint ? (
              <button
                onClick={onHint}
                className="w-full border-2 border-dashed border-gold text-gold p-2.5 sm:p-3 font-pixel text-[9px] sm:text-[10px] hover:bg-gold/10 transition-all flex items-center justify-center gap-2"
              >
                <span className="text-base">💡</span> ขอคำใบ้ (ได้ XP น้อยลง)
              </button>
            ) : (
              <div className="bg-gold/15 border-4 border-gold p-3 sm:p-4 animate-slide-up">
                <div className="font-pixel text-gold text-[9px] mb-2 flex items-center gap-2">
                  <span className="text-base">💡</span> HINT
                </div>
                <p className="font-thai text-white text-xs sm:text-base leading-relaxed">
                  {step.hint}
                </p>
              </div>
            )}
          </div>
        )}

        {/* Choices */}
        <div className="space-y-2 sm:space-y-3">
          {step.choices.map((choice, i) => {
            const letter = String.fromCharCode(65 + i);
            const isSel = selected === i;
            const isRight = i === step.correctIndex;
            const locked = answered || isSolved;

            let cls =
              "bg-retro-black/50 hover:bg-retro-black border-2 border-white/20 hover:border-gold";
            if (isSolved && isRight) cls = "bg-grass/30 border-2 border-grass";
            else if (answered) {
              if (isRight && correct) cls = "bg-grass/30 border-2 border-grass";
              else if (isSel && !correct)
                cls = "bg-retro-pink/30 border-2 border-retro-pink animate-shake";
              else cls = "bg-retro-black/50 border-2 border-white/10 opacity-60";
            }

            return (
              <button
                key={i}
                onClick={() => onSelect(i)}
                disabled={locked}
                className={`w-full text-left p-2.5 sm:p-4 transition-all ${cls} disabled:cursor-not-allowed`}
              >
                <div className="flex items-start gap-3">
                  <span
                    className={`font-pixel text-[9px] sm:text-xs px-2 py-1 min-w-[26px] text-center ${
                      (isSolved && isRight) || (answered && isRight && correct)
                        ? "bg-grass text-white"
                        : answered && isSel && !correct
                        ? "bg-retro-pink text-white"
                        : "bg-gold text-retro-black"
                    }`}
                  >
                    {letter}
                  </span>
                  <span className="font-thai text-white text-xs sm:text-base flex-1">
                    {choice}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Feedback */}
        {(answered || isSolved) && (
          <div
            className={`mt-5 p-3 sm:p-5 border-4 animate-slide-up ${
              correct || isSolved
                ? "bg-grass/20 border-grass"
                : "bg-retro-pink/20 border-retro-pink"
            }`}
          >
            <div className="flex items-center gap-2 mb-2">
              <span className="text-2xl">{correct || isSolved ? "🎉" : "🤔"}</span>
              <span
                className={`font-pixel text-[9px] sm:text-xs ${
                  correct || isSolved ? "text-grass" : "text-retro-pink"
                }`}
              >
                {correct || isSolved
                  ? showHint
                    ? "ถูกต้อง! +5 XP"
                    : attempts <= 1
                    ? "ถูกต้อง! +10 XP"
                    : "ถูกต้อง! +7 XP"
                  : "ยังไม่ถูก — ลองคิดใหม่อีกครั้ง!"}
              </span>
            </div>

            {(correct || isSolved) && (
              <p className="font-thai text-white/90 text-xs sm:text-base leading-relaxed">
                <span className="font-pixel text-gold text-[9px] block mb-1">
                  เฉลย:
                </span>
                {step.explanation}
              </p>
            )}

            {!correct && !isSolved && (
              <>
                <p className="font-thai text-white/80 text-xs sm:text-base mb-4">
                  ไม่เป็นไร! ลองทบทวนเนื้อหาด้านบน หรือกดขอคำใบ้ แล้วลองใหม่อีกครั้ง 💪
                </p>
                <button onClick={onRetry} className="pixel-btn pixel-btn-blue text-[10px]">
                  🔄 ลองใหม่อีกครั้ง
                </button>
              </>
            )}
          </div>
        )}
      </div>
    </section>
  );
}

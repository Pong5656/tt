"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import type { Question } from "@/data/questions";
import QuestionModal from "./QuestionModal";
import * as S from "./game/sprites";

type Props = {
  chapterId: string;
  chapterTitle: string;
  questions: Question[];
  bossQuestions: Question[];
  onComplete: (result: {
    score: number;
    coins: number;
    correct: number;
    wrong: number;
    hintsUsed: number;
    cleared: boolean;
  }) => void;
};

type ObjType =
  | "question"
  | "brick"
  | "coin"
  | "goomba"
  | "spiky"
  | "pipe"
  | "flag"
  | "boss";

type GameObject = {
  x: number;
  y: number;
  w: number;
  h: number;
  type: ObjType;
  used?: boolean;
  qIndex?: number;
  alive?: boolean;
  dx?: number;
  minX?: number;
  maxX?: number;
  bump?: number;
  squashTimer?: number;
};

type Particle = { x: number; y: number; vx: number; vy: number; life: number; color: string; size: number };
type FloatText = { x: number; y: number; text: string; color: string; life: number };

const GRAVITY = 0.62;
const JUMP_POWER = 13.2;
const MOVE_SPEED = 3.8;
const GROUND_Y = 392;
const VIEW_H = 480;
const MAX_HEARTS = 3;

export default function MarioGame({
  chapterTitle,
  questions,
  bossQuestions,
  onComplete,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [started, setStarted] = useState(false);
  const [score, setScore] = useState(0);
  const [coins, setCoins] = useState(5); // เริ่มต้นมีเหรียญไว้ซื้อคำใบ้
  const [hearts, setHearts] = useState(MAX_HEARTS);
  const [bossHp, setBossHp] = useState(bossQuestions.length);
  const [gameOver, setGameOver] = useState<null | "win" | "lose">(null);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [isBossQ, setIsBossQ] = useState(false);
  const [qProgress, setQProgress] = useState({ n: 0, total: questions.length + bossQuestions.length });

  const statsRef = useRef({ correct: 0, wrong: 0, hintsUsed: 0 });

  const totalBlocks = questions.length;
  const WORLD_WIDTH = Math.max(3600, 520 + totalBlocks * 430 + 900);

  const stateRef = useRef({
    player: {
      x: 90,
      y: GROUND_Y - 54,
      w: 34,
      h: 54,
      vx: 0,
      vy: 0,
      onGround: true,
      facing: 1,
      frame: 0,
      invincible: 0,
      state: "idle" as "idle" | "run" | "jump" | "hurt",
    },
    camera: 0,
    objects: [] as GameObject[],
    keys: { left: false, right: false, jump: false },
    particles: [] as Particle[],
    floats: [] as FloatText[],
    score: 0,
    coins: 5,
    hearts: MAX_HEARTS,
    bossHp: bossQuestions.length,
    bossIndex: 0,
    bossDefeated: false,
    flagRaised: 0,
    blockCooldown: 0,
    answered: new Set<number>(),
    running: false,
    t: 0,
  });

  const buildLevel = useCallback((): GameObject[] => {
    const objs: GameObject[] = [];
    const spacing = 430;

    for (let i = 0; i < totalBlocks; i++) {
      const bx = 520 + i * spacing;

      // แถวบล็อก: อิฐ - [?] - อิฐ
      objs.push({ x: bx - 44, y: GROUND_Y - 170, w: 40, h: 40, type: "brick" });
      objs.push({
        x: bx,
        y: GROUND_Y - 170,
        w: 40,
        h: 40,
        type: "question",
        used: false,
        qIndex: i,
        bump: 0,
      });
      objs.push({ x: bx + 44, y: GROUND_Y - 170, w: 40, h: 40, type: "brick" });

      // เหรียญลอยเหนือบล็อก
      for (let c = 0; c < 3; c++) {
        objs.push({
          x: bx - 34 + c * 34,
          y: GROUND_Y - 240,
          w: 20,
          h: 26,
          type: "coin",
          alive: true,
        });
      }

      // ศัตรูเดินไปมา
      const gx = bx + 150;
      objs.push({
        x: gx,
        y: GROUND_Y - 33,
        w: 34,
        h: 33,
        type: "goomba",
        alive: true,
        dx: -1.1,
        minX: gx - 90,
        maxX: gx + 90,
        squashTimer: 0,
      });

      // ศัตรูหนาม (ทับไม่ได้) สลับกันไป
      if (i % 2 === 1) {
        const sx = bx + 300;
        objs.push({
          x: sx,
          y: GROUND_Y - 120,
          w: 34,
          h: 30,
          type: "spiky",
          alive: true,
          dx: 1.4,
          minX: sx - 70,
          maxX: sx + 70,
        });
      }

      // ท่อเขียว
      if (i % 2 === 0) {
        objs.push({
          x: bx + 250,
          y: GROUND_Y - 70,
          w: 60,
          h: 70,
          type: "pipe",
        });
      }

      // แพลตฟอร์มอิฐลอย
      if (i % 3 === 1) {
        for (let b = 0; b < 3; b++) {
          objs.push({
            x: bx + 200 + b * 40,
            y: GROUND_Y - 250,
            w: 40,
            h: 40,
            type: "brick",
          });
        }
      }
    }

    // ── โซนบอส
    const bossZoneX = 520 + totalBlocks * spacing + 180;
    objs.push({
      x: bossZoneX,
      y: GROUND_Y - 170,
      w: 40,
      h: 40,
      type: "question",
      used: false,
      qIndex: -1, // -1 = boss
      bump: 0,
    });
    objs.push({
      x: bossZoneX + 180,
      y: GROUND_Y - 96,
      w: 80,
      h: 96,
      type: "boss",
      alive: true,
    });

    // ธงชัย
    objs.push({
      x: WORLD_WIDTH - 160,
      y: GROUND_Y - 260,
      w: 10,
      h: 260,
      type: "flag",
    });

    // เหรียญกระจายทั่วด่าน
    for (let i = 0; i < 28; i++) {
      objs.push({
        x: 300 + i * (WORLD_WIDTH - 600) / 28,
        y: GROUND_Y - 80 - ((i * 37) % 120),
        w: 20,
        h: 26,
        type: "coin",
        alive: true,
      });
    }

    return objs;
  }, [totalBlocks, WORLD_WIDTH]);

  const startGame = () => {
    stateRef.current = {
      player: {
        x: 90, y: GROUND_Y - 54, w: 34, h: 54,
        vx: 0, vy: 0, onGround: true, facing: 1, frame: 0,
        invincible: 0, state: "idle",
      },
      camera: 0,
      objects: buildLevel(),
      keys: { left: false, right: false, jump: false },
      particles: [],
      floats: [],
      score: 0,
      coins: 5,
      hearts: MAX_HEARTS,
      bossHp: bossQuestions.length,
      bossIndex: 0,
      bossDefeated: false,
      flagRaised: 0,
      blockCooldown: 0,
      answered: new Set<number>(),
      running: true,
      t: 0,
    };
    statsRef.current = { correct: 0, wrong: 0, hintsUsed: 0 };
    setScore(0);
    setCoins(5);
    setHearts(MAX_HEARTS);
    setBossHp(bossQuestions.length);
    setQProgress({ n: 0, total: questions.length + bossQuestions.length });
    setGameOver(null);
    setCurrentQuestion(null);
    setStarted(true);
  };

  /* ── Keyboard ── */
  useEffect(() => {
    if (!started) return;
    const down = (e: KeyboardEvent) => {
      const k = stateRef.current.keys;
      if (e.code === "ArrowLeft" || e.code === "KeyA") k.left = true;
      if (e.code === "ArrowRight" || e.code === "KeyD") k.right = true;
      if (e.code === "Space" || e.code === "ArrowUp" || e.code === "KeyW") {
        e.preventDefault();
        k.jump = true;
      }
    };
    const up = (e: KeyboardEvent) => {
      const k = stateRef.current.keys;
      if (e.code === "ArrowLeft" || e.code === "KeyA") k.left = false;
      if (e.code === "ArrowRight" || e.code === "KeyD") k.right = false;
      if (e.code === "Space" || e.code === "ArrowUp" || e.code === "KeyW") k.jump = false;
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, [started]);

  const overlap = (
    a: { x: number; y: number; w: number; h: number },
    b: { x: number; y: number; w: number; h: number }
  ) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;

  const burst = (x: number, y: number, color: string, n = 10) => {
    const s = stateRef.current;
    for (let i = 0; i < n; i++) {
      s.particles.push({
        x, y,
        vx: (Math.random() - 0.5) * 5,
        vy: -Math.random() * 5 - 1,
        life: 28 + Math.random() * 14,
        color,
        size: 3 + Math.floor(Math.random() * 3),
      });
    }
  };

  const triggerQuestion = useCallback(
    (qIndex: number) => {
      const s = stateRef.current;
      if (qIndex === -1) {
        const bq = bossQuestions[s.bossIndex];
        if (!bq) return;
        setCurrentQuestion(bq);
        setIsBossQ(true);
      } else {
        const q = questions[qIndex];
        if (!q) return;
        setCurrentQuestion(q);
        setIsBossQ(false);
      }
      setQProgress((p) => ({ ...p, n: p.n + 1 }));
    },
    [questions, bossQuestions]
  );

  /* ── Game Loop ── */
  useEffect(() => {
    if (!started || gameOver || currentQuestion) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;

    const loop = () => {
      const s = stateRef.current;
      s.t++;
      const t = s.t;
      const p = s.player;
      const W = canvas.width;
      const H = canvas.height;

      /* ═══ UPDATE ═══ */
      if (s.keys.left) {
        p.vx = -MOVE_SPEED;
        p.facing = -1;
      } else if (s.keys.right) {
        p.vx = MOVE_SPEED;
        p.facing = 1;
      } else {
        p.vx = MOVE_SPEED * 0.55; // วิ่งอัตโนมัติไปข้างหน้าเบาๆ
        p.facing = 1;
      }

      if (s.keys.jump && p.onGround) {
        p.vy = -JUMP_POWER;
        p.onGround = false;
        burst(p.x + 17, p.y + 52, "#D6D6E6", 5);
      }

      p.vy = Math.min(p.vy + GRAVITY, 16);

      // X movement + collision
      p.x += p.vx;
      if (p.x < 0) p.x = 0;
      if (p.x > WORLD_WIDTH - p.w) p.x = WORLD_WIDTH - p.w;
      for (const o of s.objects) {
        if (o.type === "coin" || o.type === "goomba" || o.type === "spiky" || o.type === "flag" || o.type === "boss") continue;
        if (overlap(p, o)) {
          if (p.vx > 0) p.x = o.x - p.w;
          else if (p.vx < 0) p.x = o.x + o.w;
        }
      }

      // Y movement + collision
      p.y += p.vy;
      p.onGround = false;
      if (p.y + p.h >= GROUND_Y) {
        p.y = GROUND_Y - p.h;
        p.vy = 0;
        p.onGround = true;
      }
      for (const o of s.objects) {
        if (o.type === "coin" || o.type === "goomba" || o.type === "spiky" || o.type === "flag" || o.type === "boss") continue;
        if (!overlap(p, o)) continue;
        if (p.vy > 0) {
          p.y = o.y - p.h;
          p.vy = 0;
          p.onGround = true;
        } else if (p.vy < 0) {
          p.y = o.y + o.h;
          p.vy = 1.2;
          if (o.type === "question" && !o.used && s.blockCooldown <= 0) {
            o.used = true;
            o.bump = 10;
            s.blockCooldown = 24;
            burst(o.x + 20, o.y, "#FFD43B", 14);
            s.floats.push({ x: o.x + 20, y: o.y - 10, text: "QUIZ!", color: "#FFD43B", life: 50 });
            triggerQuestion(o.qIndex ?? 0);
            break;
          }
          if (o.type === "brick") {
            burst(o.x + 20, o.y + 20, "#C2691F", 8);
          }
        }
      }
      if (s.blockCooldown > 0) s.blockCooldown--;

      // Block bump animation
      for (const o of s.objects) {
        if (o.bump && o.bump > 0) o.bump -= 1;
      }

      // Coins
      for (const o of s.objects) {
        if (o.type !== "coin" || !o.alive) continue;
        if (overlap(p, o)) {
          o.alive = false;
          s.coins++;
          s.score += 10;
          burst(o.x + 10, o.y + 10, "#FFC800", 8);
          s.floats.push({ x: o.x + 10, y: o.y, text: "+10", color: "#FFC800", life: 36 });
          setCoins(s.coins);
          setScore(s.score);
        }
      }

      // Enemies
      for (const o of s.objects) {
        if (o.type === "goomba") {
          if (o.squashTimer && o.squashTimer > 0) {
            o.squashTimer--;
            if (o.squashTimer === 0) o.alive = false;
            continue;
          }
          if (!o.alive) continue;
          o.x += o.dx ?? 0;
          if (o.minX !== undefined && o.x < o.minX) o.dx = Math.abs(o.dx ?? 1);
          if (o.maxX !== undefined && o.x > o.maxX) o.dx = -Math.abs(o.dx ?? 1);

          if (overlap(p, o)) {
            if (p.vy > 0 && p.y + p.h - o.y < 26) {
              o.squashTimer = 20;
              p.vy = -9;
              s.score += 50;
              burst(o.x + 17, o.y + 10, "#8A4512", 12);
              s.floats.push({ x: o.x + 17, y: o.y, text: "+50", color: "#6CE050", life: 36 });
              setScore(s.score);
            } else if (p.invincible <= 0) {
              hurtPlayer();
            }
          }
        } else if (o.type === "spiky") {
          if (!o.alive) continue;
          o.x += o.dx ?? 0;
          if (o.minX !== undefined && o.x < o.minX) o.dx = Math.abs(o.dx ?? 1);
          if (o.maxX !== undefined && o.x > o.maxX) o.dx = -Math.abs(o.dx ?? 1);
          if (overlap(p, o) && p.invincible <= 0) hurtPlayer();
        } else if (o.type === "boss" && o.alive) {
          if (overlap(p, o) && p.invincible <= 0) hurtPlayer();
        }
      }

      function hurtPlayer() {
        const st = stateRef.current;
        st.hearts--;
        st.player.invincible = 80;
        st.player.vy = -8;
        st.player.vx = -st.player.facing * 6;
        st.player.state = "hurt";
        burst(st.player.x + 17, st.player.y + 20, "#E03131", 14);
        st.floats.push({ x: st.player.x + 17, y: st.player.y, text: "-1 ♥", color: "#E03131", life: 40 });
        setHearts(st.hearts);
        if (st.hearts <= 0) setGameOver("lose");
      }

      // Flag / win
      for (const o of s.objects) {
        if (o.type !== "flag") continue;
        if (overlap(p, o)) {
          if (s.bossDefeated) {
            s.flagRaised = Math.min(1, s.flagRaised + 0.03);
            if (s.flagRaised >= 1) setGameOver("win");
          } else {
            // ยังไม่ชนะบอส ดันกลับ
            p.x = o.x - p.w - 4;
            s.floats.push({ x: p.x, y: p.y - 10, text: "BEAT BOSS!", color: "#E03131", life: 30 });
          }
        }
      }

      if (p.invincible > 0) p.invincible--;

      // animation state
      if (!p.onGround) p.state = "jump";
      else if (Math.abs(p.vx) > 0.5) p.state = "run";
      else p.state = "idle";
      if (p.state === "run") p.frame += 0.22;

      // camera
      s.camera = Math.max(0, Math.min(p.x - W / 2.6, WORLD_WIDTH - W));

      // particles
      s.particles = s.particles
        .map((q) => ({ ...q, x: q.x + q.vx, y: q.y + q.vy, vy: q.vy + 0.32, life: q.life - 1 }))
        .filter((q) => q.life > 0);
      s.floats = s.floats
        .map((f) => ({ ...f, y: f.y - 1.1, life: f.life - 1 }))
        .filter((f) => f.life > 0);

      /* ═══ RENDER ═══ */
      const scaleY = H / VIEW_H;
      ctx.save();
      ctx.scale(1, scaleY);
      const vh = VIEW_H;

      S.drawSky(ctx, W, vh, t);
      S.drawClouds(ctx, W, s.camera);
      S.drawMountains(ctx, W, GROUND_Y, s.camera);
      S.drawHills(ctx, W, GROUND_Y, s.camera);
      S.drawTrees(ctx, GROUND_Y, s.camera, W);
      S.drawBushes(ctx, GROUND_Y, s.camera, W);

      ctx.save();
      ctx.translate(-s.camera, 0);

      S.drawGround(ctx, WORLD_WIDTH, GROUND_Y, s.camera, W);

      for (const o of s.objects) {
        if (o.x + o.w < s.camera - 80 || o.x > s.camera + W + 80) continue;
        switch (o.type) {
          case "question":
            S.drawQuestionBlock(ctx, o.x, o.y, !!o.used, t, o.bump ?? 0);
            break;
          case "brick":
            S.drawBrick(ctx, o.x, o.y);
            break;
          case "coin":
            if (o.alive) S.drawCoin(ctx, o.x, o.y, t);
            break;
          case "goomba":
            if (o.alive) S.drawGoomba(ctx, o.x, o.y, t, (o.squashTimer ?? 0) > 0);
            break;
          case "spiky":
            if (o.alive) S.drawSpiky(ctx, o.x, o.y, t);
            break;
          case "pipe":
            S.drawPipe(ctx, o.x, o.y, o.w, o.h);
            break;
          case "boss":
            if (o.alive)
              S.drawBoss(ctx, o.x, o.y, t, s.bossHp, Math.max(1, bossQuestions.length));
            break;
          case "flag":
            S.drawFlag(ctx, o.x, o.y, o.h, s.flagRaised);
            break;
        }
      }

      for (const q of s.particles) S.drawParticle(ctx, q.x, q.y, q.size, q.color);
      S.drawPlayer(ctx, p.x, p.y, p.facing, p.frame, p.state, p.invincible);
      for (const f of s.floats)
        S.drawFloatingText(ctx, f.x, f.y, f.text, f.color, Math.min(1, f.life / 20));

      ctx.restore();

      S.drawProgressBar(ctx, W, Math.min(1, p.x / (WORLD_WIDTH - 200)));
      ctx.restore();

      if (!gameOver && stateRef.current.running) raf = requestAnimationFrame(loop);
    };

    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [started, gameOver, currentQuestion, WORLD_WIDTH, triggerQuestion]);

  /* ── Answer handler ── */
  const handleAnswer = (correct: boolean, usedHint: boolean) => {
    const s = stateRef.current;
    if (usedHint) {
      s.coins = Math.max(0, s.coins - 2);
      statsRef.current.hintsUsed++;
    }
    if (correct) {
      statsRef.current.correct++;
      const gain = isBossQ ? 500 : 100;
      s.score += gain;
      s.coins += isBossQ ? 8 : 3;
      s.floats.push({ x: s.player.x + 17, y: s.player.y - 20, text: `+${gain}`, color: "#6CE050", life: 50 });
      burst(s.player.x + 17, s.player.y, "#FFD43B", 18);
      s.player.vy = -7;

      if (isBossQ) {
        s.bossIndex++;
        s.bossHp = Math.max(0, bossQuestions.length - s.bossIndex);
        setBossHp(s.bossHp);
        if (s.bossIndex >= bossQuestions.length) {
          for (const o of s.objects) if (o.type === "boss") o.alive = false;
          s.bossDefeated = true;
          burst(s.player.x + 120, GROUND_Y - 60, "#7B3FA0", 40);
          s.floats.push({ x: s.player.x + 60, y: GROUND_Y - 150, text: "BOSS DOWN!", color: "#FFD43B", life: 80 });
        } else {
          // เปิดบล็อกบอสอีกครั้งสำหรับคำถามถัดไป
          for (const o of s.objects) {
            if (o.type === "question" && o.qIndex === -1) {
              o.used = false;
              break;
            }
          }
        }
      }
    } else {
      statsRef.current.wrong++;
      s.hearts--;
      s.player.invincible = 80;
      burst(s.player.x + 17, s.player.y + 20, "#E03131", 16);
      setHearts(s.hearts);
      if (isBossQ) {
        // ตอบผิดบอส → เปิดบล็อกให้ลองใหม่
        for (const o of s.objects) {
          if (o.type === "question" && o.qIndex === -1) {
            o.used = false;
            break;
          }
        }
      }
      if (s.hearts <= 0) {
        setCurrentQuestion(null);
        setGameOver("lose");
        return;
      }
    }
    setScore(s.score);
    setCoins(s.coins);
    setCurrentQuestion(null);
  };

  /* ── Resize ── */
  useEffect(() => {
    const resize = () => {
      const canvas = canvasRef.current;
      const container = containerRef.current;
      if (!canvas || !container) return;
      const w = Math.min(container.clientWidth, 960);
      canvas.width = w;
      canvas.height = Math.round(w * 0.5);
    };
    resize();
    window.addEventListener("resize", resize);
    return () => window.removeEventListener("resize", resize);
  }, []);

  /* ── Finish ── */
  useEffect(() => {
    if (!gameOver) return;
    const s = stateRef.current;
    s.running = false;
    const timer = setTimeout(() => {
      onComplete({
        score: s.score,
        coins: s.coins,
        correct: statsRef.current.correct,
        wrong: statsRef.current.wrong,
        hintsUsed: statsRef.current.hintsUsed,
        cleared: gameOver === "win",
      });
    }, 2800);
    return () => clearTimeout(timer);
  }, [gameOver, onComplete]);

  const press = (key: "left" | "right" | "jump", down: boolean) => {
    stateRef.current.keys[key] = down;
  };

  return (
    <div className="w-full">
      {/* HUD */}
      <div className="bg-retro-black border-4 border-gold p-2 sm:p-3 flex items-center justify-between flex-wrap gap-2 mb-3">
        <div className="flex items-center gap-3 sm:gap-5 flex-wrap">
          <div className="font-pixel text-[8px] sm:text-[10px] text-white">
            <span className="text-gold">SCORE</span>{" "}
            {score.toString().padStart(6, "0")}
          </div>
          <div className="font-pixel text-[8px] sm:text-[10px] text-coin">
            🪙 × {coins}
          </div>
          <div className="flex items-center gap-1">
            {Array.from({ length: MAX_HEARTS }).map((_, i) => (
              <span
                key={i}
                className={`text-base sm:text-xl ${i < hearts ? "" : "opacity-20 grayscale"}`}
              >
                ❤️
              </span>
            ))}
          </div>
          {bossQuestions.length > 0 && (
            <div className="font-pixel text-[8px] sm:text-[10px] text-retro-pink">
              👹 {bossHp}/{bossQuestions.length}
            </div>
          )}
        </div>
        <div className="font-pixel text-[8px] sm:text-[10px] text-grass">
          Q {qProgress.n}/{qProgress.total}
        </div>
      </div>

      {/* Canvas */}
      <div
        ref={containerRef}
        className="relative w-full border-4 border-retro-black bg-sky overflow-hidden scanlines"
        style={{ aspectRatio: "2/1" }}
      >
        <canvas
          ref={canvasRef}
          className="block w-full h-full"
          style={{ imageRendering: "pixelated" }}
        />

        {!started && (
          <div className="absolute inset-0 bg-retro-black/85 flex flex-col items-center justify-center p-4 text-center">
            <h2 className="font-pixel text-gold text-lg sm:text-3xl pixel-text-shadow mb-3">
              READY?
            </h2>
            <p className="font-thai text-white text-sm sm:text-base mb-2">
              ด่าน: {chapterTitle}
            </p>
            <div className="font-thai text-white/75 text-xs sm:text-sm mb-5 max-w-lg space-y-1">
              <p>🏃 กระโดดชน <span className="text-gold font-bold">[?] Block</span> เพื่อเปิดโจทย์ฟิสิกส์</p>
              <p>💡 ติดขัด? กด <span className="text-gold font-bold">ขอคำใบ้</span> ได้ (จ่าย 2 เหรียญ)</p>
              <p>👹 ท้ายด่านมี <span className="text-retro-pink font-bold">บอส {bossQuestions.length} ข้อ</span> รอท้าทาย!</p>
            </div>
            <button onClick={startGame} className="pixel-btn pixel-btn-green text-xs sm:text-sm">
              ▶ START GAME
            </button>
          </div>
        )}

        {gameOver && (
          <div className="absolute inset-0 bg-retro-black/90 flex flex-col items-center justify-center p-4 text-center">
            <div className="text-5xl sm:text-7xl mb-3 animate-bounce-block">
              {gameOver === "win" ? "🏆" : "💀"}
            </div>
            <h2
              className={`font-pixel text-lg sm:text-3xl pixel-text-shadow mb-2 ${
                gameOver === "win" ? "text-gold" : "text-retro-pink"
              }`}
            >
              {gameOver === "win" ? "STAGE CLEAR!" : "GAME OVER"}
            </h2>
            <p className="font-thai text-white text-sm mb-3">
              {gameOver === "win"
                ? `พิชิตบอส ${chapterTitle} สำเร็จ!`
                : "ลองทบทวนในโหมดบทเรียนแล้วกลับมาใหม่!"}
            </p>
            <p className="font-pixel text-white text-xs">
              SCORE <span className="text-gold">{score}</span>
            </p>
            <div className="font-pixel text-white/50 text-[9px] mt-4 animate-blink">
              LOADING RESULTS...
            </div>
          </div>
        )}
      </div>

      {/* Touch controls */}
      {started && !gameOver && (
        <div className="mt-3 flex items-center justify-between gap-3 lg:hidden">
          <div className="flex gap-2">
            {(["left", "right"] as const).map((dir) => (
              <button
                key={dir}
                onTouchStart={(e) => { e.preventDefault(); press(dir, true); }}
                onTouchEnd={(e) => { e.preventDefault(); press(dir, false); }}
                onMouseDown={() => press(dir, true)}
                onMouseUp={() => press(dir, false)}
                onMouseLeave={() => press(dir, false)}
                className="pixel-btn w-16 h-16 text-2xl flex items-center justify-center"
                style={{ padding: 0 }}
              >
                {dir === "left" ? "◀" : "▶"}
              </button>
            ))}
          </div>
          <button
            onTouchStart={(e) => { e.preventDefault(); press("jump", true); }}
            onTouchEnd={(e) => { e.preventDefault(); press("jump", false); }}
            onMouseDown={() => press("jump", true)}
            onMouseUp={() => press("jump", false)}
            onMouseLeave={() => press("jump", false)}
            className="pixel-btn pixel-btn-red w-24 h-16 text-[10px] flex items-center justify-center"
            style={{ padding: 0 }}
          >
            JUMP ▲
          </button>
        </div>
      )}

      {started && !gameOver && (
        <div className="hidden lg:flex mt-3 gap-2 flex-wrap font-pixel text-[9px] text-white">
          <span className="bg-retro-black px-2 py-1 border-2 border-gold">← → MOVE</span>
          <span className="bg-retro-black px-2 py-1 border-2 border-gold">SPACE JUMP</span>
          <span className="bg-retro-black px-2 py-1 border-2 border-grass">HIT [?] = QUIZ</span>
          <span className="bg-retro-black px-2 py-1 border-2 border-retro-pink">STOMP GOOMBA · AVOID SPIKES</span>
        </div>
      )}

      {currentQuestion && (
        <QuestionModal
          question={currentQuestion}
          onAnswer={handleAnswer}
          isBoss={isBossQ}
          coins={coins}
          hintCost={2}
          questionNumber={qProgress.n}
          questionTotal={qProgress.total}
        />
      )}
    </div>
  );
}

"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export default function Navbar() {
  const pathname = usePathname();

  const links = [
    { href: "/", label: "HOME", emoji: "🏠" },
    { href: "/lesson", label: "LESSON", emoji: "📖" },
    { href: "/study", label: "STUDY", emoji: "📚" },
    { href: "/arcade", label: "ARCADE", emoji: "🎮" },
    { href: "/profile", label: "PROFILE", emoji: "👤" },
  ];

  return (
    <nav className="sticky top-0 z-40 bg-retro-black border-b-4 border-gold">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 sm:gap-3 group">
            <div className="question-block w-10 h-10 sm:w-12 sm:h-12 animate-bounce-block">
              <span className="text-lg sm:text-2xl">?</span>
            </div>
            <div className="hidden sm:block">
              <div className="font-pixel text-gold text-xs sm:text-sm pixel-text-shadow-sm">
                PIXEL
              </div>
              <div className="font-pixel text-white text-[10px] sm:text-xs">
                PHYSICS
              </div>
            </div>
            <div className="sm:hidden">
              <div className="font-pixel text-gold text-[10px] pixel-text-shadow-sm">
                PIXEL
              </div>
              <div className="font-pixel text-white text-[8px]">PHYSICS</div>
            </div>
          </Link>

          {/* Nav Links */}
          <div className="flex items-center gap-1 sm:gap-2">
            {links.map((link) => {
              const active =
                pathname === link.href ||
                (link.href !== "/" && pathname?.startsWith(link.href));
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`relative px-1.5 sm:px-3 py-2 font-pixel text-[7px] sm:text-[10px] transition-all ${
                    active
                      ? "text-gold"
                      : "text-white/70 hover:text-white"
                  }`}
                >
                  <div className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2">
                    <span className="text-base sm:text-lg">{link.emoji}</span>
                    <span>{link.label}</span>
                  </div>
                  {active && (
                    <div className="absolute -bottom-2 left-0 right-0 h-1 bg-gold" />
                  )}
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
}

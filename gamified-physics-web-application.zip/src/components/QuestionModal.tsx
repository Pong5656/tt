"use client";

import type { Question } from "@/data/questions";
import { useState } from "react";

type Props = {
  question: Question;
  onAnswer: (correct: boolean, usedHint: boolean) => void;
  isBoss?: boolean;
  coins?: number;
  /** ราคาคำใบ้ (เหรียญ) */
  hintCost?: number;
  questionNumber?: number;
  questionTotal?: number;
};

export default function QuestionModal({
  question,
  onAnswer,
  isBoss,
  coins = 0,
  hintCost = 2,
  questionNumber,
  questionTotal,
}: Props) {
  const [selected, setSelected] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const isCorrect = selected === question.correctIndex;
  const canAffordHint = coins >= hintCost;

  const handleSelect = (idx: number) => {
    if (answered) return;
    setSelected(idx);
    setAnswered(true);
  };

  const difficultyBadge = {
    easy: { label: "EASY", color: "bg-grass text-white" },
    medium: { label: "MEDIUM", color: "bg-gold text-retro-black" },
    hard: { label: "HARD", color: "bg-retro-pink text-white" },
    boss: { label: "BOSS", color: "bg-retro-purple text-white" },
  }[question.difficulty];

  return (
    <div className="fixed inset-0 z-50 flex items-start sm:items-center justify-center bg-retro-black/90 p-2 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-retro-navy border-4 border-gold my-2 sm:my-4 animate-slide-up">
        <div
          className="absolute inset-0 pointer-events-none opacity-20"
          style={{
            backgroundImage:
              "repeating-linear-gradient(0deg, rgba(0,0,0,0.3) 0, rgba(0,0,0,0.3) 1px, transparent 1px, transparent 3px)",
          }}
        />

        {/* Header */}
        <div className="relative bg-retro-black border-b-4 border-gold p-2 sm:p-4 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
            <div
              className={`px-2 py-1 font-pixel text-[8px] sm:text-[10px] ${difficultyBadge.color}`}
            >
              {difficultyBadge.label}
            </div>
            {isBoss && (
              <span className="font-pixel text-retro-pink text-[9px] sm:text-xs animate-blink">
                ⚔ BOSS ⚔
              </span>
            )}
            {questionNumber && questionTotal && (
              <span className="font-pixel text-white/60 text-[8px] sm:text-[10px]">
                Q{questionNumber}/{questionTotal}
              </span>
            )}
          </div>
          <div className="font-pixel text-coin text-[8px] sm:text-[10px]">
            🪙 {coins}
          </div>
        </div>

        <div className="relative p-3 sm:p-6">
          {/* Objective tag */}
          <div className="mb-3 bg-retro-black/50 border-l-4 border-grass px-3 py-2">
            <div className="font-pixel text-grass text-[7px] sm:text-[9px] mb-1">
              📘 สสวท. OBJECTIVE
            </div>
            <div className="font-thai text-white/70 text-[11px] sm:text-xs">
              {question.objective}
              {question.source && (
                <span className="text-gold"> · {question.source}</span>
              )}
            </div>
          </div>

          {/* Question */}
          <div className="font-thai text-white text-sm sm:text-lg leading-relaxed mb-4 sm:mb-6">
            {question.question}
          </div>

          {/* Hint Button / Panel */}
          {!answered && (
            <div className="mb-4">
              {!showHint ? (
                <button
                  onClick={() => canAffordHint && setShowHint(true)}
                  disabled={!canAffordHint}
                  className={`w-full border-2 border-dashed p-2 sm:p-3 font-pixel text-[9px] sm:text-[10px] transition-all flex items-center justify-center gap-2 ${
                    canAffordHint
                      ? "border-gold text-gold hover:bg-gold/10 cursor-pointer"
                      : "border-white/20 text-white/30 cursor-not-allowed"
                  }`}
                >
                  <span className="text-base">💡</span>
                  ขอคำใบ้ (−{hintCost} 🪙)
                  {!canAffordHint && <span>· เหรียญไม่พอ</span>}
                </button>
              ) : (
                <div className="bg-gold/15 border-4 border-gold p-3 sm:p-4 animate-slide-up">
                  <div className="font-pixel text-gold text-[9px] sm:text-[10px] mb-2 flex items-center gap-2">
                    <span className="text-base">💡</span> HINT
                  </div>
                  <div className="font-thai text-white text-xs sm:text-base leading-relaxed">
                    {question.hint}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Choices */}
          <div className="space-y-2 sm:space-y-3">
            {question.choices.map((choice, idx) => {
              const letter = String.fromCharCode(65 + idx);
              const isSelected = selected === idx;
              const isCorrectChoice = idx === question.correctIndex;

              let bgClass =
                "bg-retro-black/50 hover:bg-retro-black border-2 border-white/20 hover:border-gold";
              if (answered) {
                if (isCorrectChoice) {
                  bgClass = "bg-grass/30 border-2 border-grass";
                } else if (isSelected) {
                  bgClass =
                    "bg-retro-pink/30 border-2 border-retro-pink animate-shake";
                } else {
                  bgClass =
                    "bg-retro-black/50 border-2 border-white/10 opacity-50";
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelect(idx)}
                  disabled={answered}
                  className={`w-full text-left p-2.5 sm:p-4 transition-all ${bgClass} disabled:cursor-not-allowed`}
                >
                  <div className="flex items-start gap-2 sm:gap-3">
                    <span
                      className={`font-pixel text-[9px] sm:text-xs px-2 py-1 min-w-[26px] text-center ${
                        answered && isCorrectChoice
                          ? "bg-grass text-white"
                          : answered && isSelected
                          ? "bg-retro-pink text-white"
                          : "bg-gold text-retro-black"
                      }`}
                    >
                      {letter}
                    </span>
                    <span className="font-thai text-white text-xs sm:text-base flex-1">
                      {choice}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Feedback */}
          {answered && (
            <div
              className={`mt-4 sm:mt-6 p-3 sm:p-4 border-4 animate-slide-up ${
                isCorrect
                  ? "bg-grass/20 border-grass"
                  : "bg-retro-pink/20 border-retro-pink"
              }`}
            >
              <div className="flex items-center gap-2 mb-2">
                <span className="text-2xl sm:text-3xl">
                  {isCorrect ? "🎉" : "💔"}
                </span>
                <span
                  className={`font-pixel text-[9px] sm:text-xs ${
                    isCorrect ? "text-grass" : "text-retro-pink"
                  }`}
                >
                  {isCorrect
                    ? showHint
                      ? "CORRECT! (ใช้คำใบ้)"
                      : "CORRECT! PERFECT!"
                    : "WRONG! −1 HEART"}
                </span>
              </div>
              <div className="font-thai text-white/90 text-xs sm:text-base leading-relaxed">
                <span className="font-pixel text-gold text-[9px] sm:text-xs mr-2 block mb-1">
                  SOLUTION:
                </span>
                {question.explanation}
              </div>
            </div>
          )}

          {answered && (
            <div className="mt-4 sm:mt-6 flex justify-center">
              <button
                onClick={() => onAnswer(isCorrect, showHint)}
                className={`pixel-btn ${
                  isCorrect ? "pixel-btn-green" : "pixel-btn-red"
                } text-[10px] sm:text-xs`}
              >
                {isCorrect ? "► CONTINUE" : "► RESPAWN"}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

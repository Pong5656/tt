import type { ReactNode } from "react";
import Navbar from "./Navbar";

export default function RetroLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen retro-sky relative">
      <Navbar />
      <main className="relative">{children}</main>
      {/* Decorative ground */}
      <div className="relative h-16 sm:h-24 mt-8">
        <div className="absolute top-0 left-0 right-0 h-4 retro-ground-green" />
        <div className="absolute top-4 left-0 right-0 bottom-0 retro-ground" />
      </div>
    </div>
  );
}

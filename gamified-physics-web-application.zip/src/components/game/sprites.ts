/**
 * 2D Pixel-art sprite renderer สำหรับ Arcade Mode
 * วาดทุกอย่างด้วย Canvas 2D โดยใช้บล็อกพิกเซลขนาด 2-4 px
 * เพื่อให้ได้อารมณ์เกม 8-bit ที่มีมิติ (เงา, ไฮไลต์, ชั้นสี)
 */

export type Ctx = CanvasRenderingContext2D;

const px = (ctx: Ctx, x: number, y: number, w: number, h: number, color: string) => {
  ctx.fillStyle = color;
  ctx.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
};

/* ─────────────────────────────────────────────
   BACKGROUND LAYERS (parallax)
   ───────────────────────────────────────────── */

export function drawSky(ctx: Ctx, w: number, h: number, t: number) {
  // ไล่สีท้องฟ้าแบบ 8-bit (แบ่งเป็นแถบชัดเจน ไม่ใช่ gradient เนียน)
  const bands = [
    "#4A86E8",
    "#5C94FC",
    "#6FA4FF",
    "#86B5FF",
    "#9CC4FF",
    "#B4D2FF",
  ];
  const bandH = h / bands.length;
  bands.forEach((c, i) => px(ctx, 0, i * bandH, w, bandH + 1, c));

  // ดวงอาทิตย์พิกเซล
  const sunX = w - 90;
  const sunY = 60;
  const pulse = Math.sin(t / 60) * 2;
  px(ctx, sunX - 20, sunY - 20 - pulse, 40, 40, "#FFE66D");
  px(ctx, sunX - 24, sunY - 12 - pulse, 48, 24, "#FFE66D");
  px(ctx, sunX - 12, sunY - 24 - pulse, 24, 48, "#FFE66D");
  px(ctx, sunX - 14, sunY - 14 - pulse, 28, 28, "#FFF7B2");
}

export function drawClouds(ctx: Ctx, w: number, camera: number) {
  const off = camera * 0.15;
  for (let i = 0; i < 14; i++) {
    const cx = ((i * 420 - off) % (w + 400)) - 200;
    const cy = 40 + ((i * 37) % 70);
    const s = 1 + ((i % 3) * 0.35);
    drawCloud(ctx, cx, cy, s);
  }
}

function drawCloud(ctx: Ctx, x: number, y: number, s: number) {
  const W = "#FFFFFF";
  const S = "#D6E6FF";
  px(ctx, x, y + 10 * s, 70 * s, 14 * s, W);
  px(ctx, x + 12 * s, y + 2 * s, 44 * s, 12 * s, W);
  px(ctx, x + 26 * s, y - 5 * s, 24 * s, 12 * s, W);
  // เงาด้านล่าง
  px(ctx, x, y + 20 * s, 70 * s, 4 * s, S);
  px(ctx, x + 6 * s, y + 24 * s, 56 * s, 3 * s, S);
}

export function drawMountains(ctx: Ctx, w: number, groundY: number, camera: number) {
  const off = camera * 0.25;
  for (let i = 0; i < 12; i++) {
    const mx = i * 420 - off;
    if (mx + 380 < 0 || mx > w) continue;
    drawMountain(ctx, mx, groundY, 170);
  }
}

function drawMountain(ctx: Ctx, x: number, baseY: number, height: number) {
  const step = 10;
  const rows = Math.floor(height / step);
  for (let r = 0; r < rows; r++) {
    const halfW = (r + 1) * 11;
    const y = baseY - height + r * step;
    px(ctx, x - halfW, y, halfW * 2, step + 1, "#5B7FA6");
    // ด้านสว่าง
    px(ctx, x - halfW, y, halfW * 0.45, step + 1, "#7FA3C9");
  }
  // ยอดหิมะ
  px(ctx, x - 14, baseY - height, 28, 14, "#E8F1FF");
  px(ctx, x - 22, baseY - height + 10, 44, 8, "#E8F1FF");
}

export function drawHills(ctx: Ctx, w: number, groundY: number, camera: number) {
  const off = camera * 0.5;
  for (let i = 0; i < 16; i++) {
    const hx = i * 300 - off;
    if (hx + 260 < 0 || hx > w) continue;
    drawHill(ctx, hx, groundY, (i % 2 === 0 ? 90 : 60));
  }
}

function drawHill(ctx: Ctx, x: number, baseY: number, height: number) {
  const step = 8;
  const rows = Math.floor(height / step);
  for (let r = 0; r < rows; r++) {
    const halfW = (r + 1) * 14;
    const y = baseY - height + r * step;
    px(ctx, x - halfW, y, halfW * 2, step + 1, "#2E9E14");
    px(ctx, x - halfW, y, halfW * 0.4, step + 1, "#43C224");
  }
}

export function drawBushes(ctx: Ctx, groundY: number, camera: number, w: number) {
  const off = camera * 0.85;
  for (let i = 0; i < 40; i++) {
    const bx = i * 260 - off;
    if (bx + 120 < 0 || bx > w) continue;
    drawBush(ctx, bx, groundY - 26);
  }
}

function drawBush(ctx: Ctx, x: number, y: number) {
  const D = "#1E8C00";
  const M = "#3CBC18";
  const L = "#6CE050";
  px(ctx, x, y + 12, 96, 16, D);
  px(ctx, x + 6, y + 2, 28, 24, M);
  px(ctx, x + 34, y - 6, 30, 32, M);
  px(ctx, x + 62, y + 2, 28, 24, M);
  px(ctx, x + 10, y + 4, 10, 6, L);
  px(ctx, x + 40, y - 3, 12, 6, L);
  px(ctx, x + 66, y + 4, 10, 6, L);
}

export function drawTrees(ctx: Ctx, groundY: number, camera: number, w: number) {
  const off = camera * 0.7;
  for (let i = 0; i < 30; i++) {
    const tx = i * 340 + 120 - off;
    if (tx + 80 < 0 || tx > w) continue;
    drawTree(ctx, tx, groundY);
  }
}

function drawTree(ctx: Ctx, x: number, baseY: number) {
  px(ctx, x + 18, baseY - 44, 14, 44, "#7A4A17");
  px(ctx, x + 18, baseY - 44, 5, 44, "#9C6428");
  // ทรงพุ่มสามชั้น
  px(ctx, x - 2, baseY - 70, 54, 26, "#1E8C00");
  px(ctx, x + 4, baseY - 88, 42, 24, "#2AA40C");
  px(ctx, x + 12, baseY - 102, 26, 20, "#3CBC18");
  px(ctx, x + 16, baseY - 98, 8, 8, "#6CE050");
}

/* ─────────────────────────────────────────────
   GROUND / TILES
   ───────────────────────────────────────────── */

export function drawGround(
  ctx: Ctx,
  worldWidth: number,
  groundY: number,
  camera: number,
  viewW: number
) {
  const startX = Math.max(0, Math.floor((camera - 64) / 32) * 32);
  const endX = Math.min(worldWidth, camera + viewW + 64);

  for (let x = startX; x < endX; x += 32) {
    // ชั้นหญ้า
    px(ctx, x, groundY - 10, 32, 10, "#3CBC18");
    px(ctx, x, groundY - 10, 32, 3, "#6CE050");
    // ใบหญ้าขอบบน
    px(ctx, x + 4, groundY - 13, 4, 3, "#6CE050");
    px(ctx, x + 14, groundY - 14, 4, 4, "#6CE050");
    px(ctx, x + 24, groundY - 13, 4, 3, "#6CE050");
    // ชั้นดิน
    px(ctx, x, groundY, 32, 70, "#A05A1E");
    px(ctx, x, groundY, 32, 5, "#C87820");
    // ลายอิฐดิน
    px(ctx, x, groundY + 18, 32, 2, "#7A4010");
    px(ctx, x, groundY + 40, 32, 2, "#7A4010");
    px(ctx, x + 15, groundY + 5, 2, 13, "#7A4010");
    px(ctx, x + 2, groundY + 20, 2, 20, "#7A4010");
    px(ctx, x + 28, groundY + 20, 2, 20, "#7A4010");
    // ก้อนกรวด
    if ((x / 32) % 3 === 0) {
      px(ctx, x + 8, groundY + 26, 5, 5, "#C89050");
      px(ctx, x + 20, groundY + 48, 4, 4, "#C89050");
    }
  }
}

/* ─────────────────────────────────────────────
   PLAYER SPRITE (2D animated)
   ───────────────────────────────────────────── */

export function drawPlayer(
  ctx: Ctx,
  x: number,
  y: number,
  facing: number,
  frame: number,
  state: "idle" | "run" | "jump" | "hurt",
  invincible: number
) {
  if (invincible > 0 && Math.floor(invincible / 4) % 2 === 0) return;

  ctx.save();
  if (facing < 0) {
    ctx.translate(x + 34, y);
    ctx.scale(-1, 1);
  } else {
    ctx.translate(x, y);
  }

  const RED = "#E03131";
  const RED_D = "#A51111";
  const BLUE = "#1C6FD0";
  const BLUE_D = "#124A91";
  const SKIN = "#FFC79B";
  const SKIN_D = "#D99A6C";
  const HAIR = "#4A2512";
  const SHOE = "#5B2E0E";
  const YEL = "#FFD43B";

  const f = Math.floor(frame) % 4;
  const bob = state === "run" ? (f === 1 || f === 3 ? 1 : 0) : 0;
  const Y = bob;

  // ── เงาใต้ตัว
  ctx.globalAlpha = 0.22;
  px(ctx, 2, 50, 30, 5, "#000000");
  ctx.globalAlpha = 1;

  // ── หมวก
  px(ctx, 7, 0 + Y, 20, 6, RED);
  px(ctx, 4, 4 + Y, 28, 5, RED);
  px(ctx, 25, 5 + Y, 10, 4, RED_D); // ปีกหมวก
  px(ctx, 9, 1 + Y, 8, 3, "#FF5B5B"); // ไฮไลต์
  // โลโก้ ⚛ บนหมวก
  px(ctx, 15, 1 + Y, 4, 4, "#FFFFFF");

  // ── ผมข้าง
  px(ctx, 5, 9 + Y, 5, 6, HAIR);

  // ── ใบหน้า
  px(ctx, 8, 9 + Y, 20, 13, SKIN);
  px(ctx, 8, 19 + Y, 20, 3, SKIN_D);
  // ตา
  px(ctx, 19, 12 + Y, 4, 5, "#FFFFFF");
  px(ctx, 21, 13 + Y, 2, 3, "#1A1A2E");
  // คิ้ว
  px(ctx, 19, 10 + Y, 5, 2, HAIR);
  // จมูก
  px(ctx, 26, 15 + Y, 4, 4, SKIN_D);
  // หนวด
  px(ctx, 17, 19 + Y, 10, 3, HAIR);

  // ── ลำตัว/เสื้อ
  px(ctx, 7, 22 + Y, 22, 11, BLUE);
  px(ctx, 7, 22 + Y, 22, 3, "#2E8BE8");
  // กระดุมทอง
  px(ctx, 12, 25 + Y, 3, 3, YEL);
  px(ctx, 21, 25 + Y, 3, 3, YEL);

  // ── แขน (ขยับตามเฟรม)
  const armSwing = state === "run" ? [0, 3, 0, -3][f] : state === "jump" ? -5 : 0;
  px(ctx, 2, 23 + Y + armSwing, 6, 11, RED);
  px(ctx, 2, 32 + Y + armSwing, 6, 5, SKIN);
  px(ctx, 28, 23 + Y - armSwing, 6, 11, RED);
  px(ctx, 28, 32 + Y - armSwing, 6, 5, SKIN);

  // ── กางเกง
  px(ctx, 8, 33 + Y, 20, 9, BLUE_D);
  px(ctx, 8, 33 + Y, 20, 2, BLUE);

  // ── ขา
  if (state === "jump") {
    px(ctx, 7, 42, 9, 7, BLUE_D);
    px(ctx, 5, 47, 12, 5, SHOE);
    px(ctx, 20, 42, 9, 9, BLUE_D);
    px(ctx, 19, 49, 13, 5, SHOE);
  } else if (state === "run") {
    const legs = [
      [42, 45],
      [45, 42],
      [43, 44],
      [45, 42],
    ][f];
    px(ctx, 8, legs[0], 8, 54 - legs[0] - 4, BLUE_D);
    px(ctx, 6, 50, 12, 5, SHOE);
    px(ctx, 19, legs[1], 8, 54 - legs[1] - 4, BLUE_D);
    px(ctx, 18, 50, 12, 5, SHOE);
  } else {
    px(ctx, 8, 42, 8, 8, BLUE_D);
    px(ctx, 6, 50, 12, 5, SHOE);
    px(ctx, 19, 42, 8, 8, BLUE_D);
    px(ctx, 18, 50, 12, 5, SHOE);
  }

  ctx.restore();
}

/* ─────────────────────────────────────────────
   BLOCKS
   ───────────────────────────────────────────── */

export function drawQuestionBlock(
  ctx: Ctx,
  x: number,
  y: number,
  used: boolean,
  t: number,
  bumpOffset = 0
) {
  const S = 40;
  const yy = y - bumpOffset;

  if (used) {
    px(ctx, x, yy, S, S, "#8A5A20");
    px(ctx, x + 3, yy + 3, S - 6, S - 6, "#6B4315");
    px(ctx, x, yy, S, 3, "#A5703A");
    px(ctx, x, yy + S - 3, S, 3, "#4A2D0C");
    return;
  }

  const bob = Math.sin(t / 18) * 1.5;
  const Y = yy + bob;

  // กรอบนอกเข้ม
  px(ctx, x, Y, S, S, "#1A1A2E");
  // หน้าบล็อก
  px(ctx, x + 2, Y + 2, S - 4, S - 4, "#F2A40C");
  // ไฮไลต์บน-ซ้าย
  px(ctx, x + 2, Y + 2, S - 4, 4, "#FFD966");
  px(ctx, x + 2, Y + 2, 4, S - 4, "#FFD966");
  // เงาล่าง-ขวา
  px(ctx, x + 2, Y + S - 8, S - 4, 6, "#B06A00");
  px(ctx, x + S - 8, Y + 2, 6, S - 4, "#B06A00");
  // หมุดมุม
  [[5, 5], [S - 10, 5], [5, S - 10], [S - 10, S - 10]].forEach(([dx, dy]) =>
    px(ctx, x + dx, Y + dy, 4, 4, "#8A4E00")
  );

  // เครื่องหมาย ? แบบพิกเซล
  const qx = x + 13;
  const qy = Y + 9;
  const W = "#FFFFFF";
  const Sh = "#8A4E00";
  px(ctx, qx + 1, qy + 1, 12, 4, Sh);
  px(ctx, qx, qy, 12, 4, W);
  px(ctx, qx + 9, qy + 4, 4, 5, W);
  px(ctx, qx + 5, qy + 8, 8, 4, W);
  px(ctx, qx + 5, qy + 12, 4, 4, W);
  px(ctx, qx + 5, qy + 19, 4, 4, W);

  // ประกายวิบวับ
  const sp = Math.floor(t / 14) % 4;
  if (sp === 0) px(ctx, x + 32, Y + 6, 3, 3, "#FFFFFF");
  if (sp === 2) px(ctx, x + 7, Y + 30, 3, 3, "#FFFFFF");
}

export function drawBrick(ctx: Ctx, x: number, y: number) {
  const S = 40;
  px(ctx, x, y, S, S, "#1A1A2E");
  px(ctx, x + 2, y + 2, S - 4, S - 4, "#C2691F");
  px(ctx, x + 2, y + 2, S - 4, 3, "#E89A4E");
  px(ctx, x + 2, y + S - 6, S - 4, 4, "#8A3F0A");
  // ลายอิฐสลับฟัน
  px(ctx, x + 2, y + 13, S - 4, 3, "#8A3F0A");
  px(ctx, x + 2, y + 26, S - 4, 3, "#8A3F0A");
  px(ctx, x + 19, y + 2, 3, 11, "#8A3F0A");
  px(ctx, x + 10, y + 16, 3, 10, "#8A3F0A");
  px(ctx, x + 28, y + 16, 3, 10, "#8A3F0A");
  px(ctx, x + 19, y + 29, 3, 9, "#8A3F0A");
}

export function drawPipe(ctx: Ctx, x: number, y: number, w: number, h: number) {
  // ลำท่อ
  px(ctx, x + 4, y + 16, w - 8, h - 16, "#1A1A2E");
  px(ctx, x + 6, y + 16, w - 12, h - 16, "#2AA40C");
  px(ctx, x + 8, y + 16, 7, h - 16, "#6CE050");
  px(ctx, x + w - 16, y + 16, 8, h - 16, "#146A00");
  // ปากท่อ
  px(ctx, x - 4, y, w + 8, 18, "#1A1A2E");
  px(ctx, x - 2, y + 2, w + 4, 14, "#2AA40C");
  px(ctx, x, y + 3, 9, 11, "#6CE050");
  px(ctx, x + w - 8, y + 3, 8, 11, "#146A00");
  px(ctx, x - 2, y + 12, w + 4, 4, "#146A00");
}

/* ─────────────────────────────────────────────
   COLLECTIBLES / ENEMIES
   ───────────────────────────────────────────── */

export function drawCoin(ctx: Ctx, x: number, y: number, t: number) {
  const phase = Math.sin(t / 7);
  const w = Math.max(4, Math.abs(phase) * 18);
  const cx = x + 10 - w / 2;
  px(ctx, cx, y, w, 26, "#B07800");
  px(ctx, cx + 1, y + 1, Math.max(2, w - 2), 24, "#FFC800");
  if (w > 9) {
    px(ctx, cx + 3, y + 4, Math.max(2, w - 7), 18, "#FFE066");
    px(ctx, cx + Math.floor(w / 2) - 1, y + 7, 3, 12, "#B07800");
  }
  if (phase > 0.75) px(ctx, cx + 2, y + 3, 2, 5, "#FFFFFF");
}

export function drawGoomba(ctx: Ctx, x: number, y: number, t: number, squashed = false) {
  if (squashed) {
    px(ctx, x, y + 22, 34, 10, "#7A3D0A");
    px(ctx, x + 4, y + 24, 26, 6, "#A05A1E");
    return;
  }
  const walk = Math.floor(t / 9) % 2;
  // เงา
  ctx.globalAlpha = 0.2;
  px(ctx, x + 2, y + 30, 30, 4, "#000");
  ctx.globalAlpha = 1;
  // หัวเห็ด
  px(ctx, x + 5, y, 24, 6, "#1A1A2E");
  px(ctx, x + 1, y + 4, 32, 18, "#1A1A2E");
  px(ctx, x + 6, y + 2, 22, 5, "#A05A1E");
  px(ctx, x + 2, y + 6, 30, 14, "#8A4512");
  px(ctx, x + 6, y + 3, 9, 4, "#C27A33");
  // ใบหน้า
  px(ctx, x + 5, y + 20, 24, 9, "#F2C891");
  // ตาโกรธ
  px(ctx, x + 8, y + 9, 7, 8, "#FFFFFF");
  px(ctx, x + 19, y + 9, 7, 8, "#FFFFFF");
  px(ctx, x + 11, y + 11, 3, 4, "#1A1A2E");
  px(ctx, x + 20, y + 11, 3, 4, "#1A1A2E");
  px(ctx, x + 8, y + 8, 7, 2, "#1A1A2E");
  px(ctx, x + 19, y + 8, 7, 2, "#1A1A2E");
  // เท้า
  px(ctx, x, y + 28 + (walk ? 0 : 2), 13, 5, "#1A1A2E");
  px(ctx, x + 20, y + 28 + (walk ? 2 : 0), 13, 5, "#1A1A2E");
}

export function drawSpiky(ctx: Ctx, x: number, y: number, t: number) {
  const bob = Math.sin(t / 10) * 2;
  const Y = y + bob;
  // ตัวหนามสีม่วง
  px(ctx, x + 4, Y + 8, 26, 20, "#1A1A2E");
  px(ctx, x + 6, Y + 10, 22, 16, "#7B3FA0");
  px(ctx, x + 8, Y + 11, 8, 6, "#A66FD0");
  // หนาม
  for (let i = 0; i < 4; i++) {
    px(ctx, x + 5 + i * 7, Y + 2, 5, 7, "#D6D6E6");
    px(ctx, x + 6 + i * 7, Y, 3, 4, "#FFFFFF");
  }
  // ตา
  px(ctx, x + 9, Y + 16, 5, 6, "#FFFFFF");
  px(ctx, x + 19, Y + 16, 5, 6, "#FFFFFF");
  px(ctx, x + 11, Y + 18, 2, 3, "#E03131");
  px(ctx, x + 20, Y + 18, 2, 3, "#E03131");
}

export function drawBoss(ctx: Ctx, x: number, y: number, t: number, hp: number, maxHp: number) {
  const bob = Math.sin(t / 14) * 3;
  const Y = y + bob;
  const W = 80;
  const H = 96;

  // เงา
  ctx.globalAlpha = 0.25;
  px(ctx, x + 6, y + H - 2, W - 12, 7, "#000");
  ctx.globalAlpha = 1;

  // มงกุฎ
  px(ctx, x + 12, Y - 20, 56, 14, "#C79400");
  px(ctx, x + 14, Y - 18, 52, 6, "#FFD43B");
  px(ctx, x + 14, Y - 30, 10, 12, "#FFD43B");
  px(ctx, x + 35, Y - 34, 10, 16, "#FFD43B");
  px(ctx, x + 56, Y - 30, 10, 12, "#FFD43B");
  px(ctx, x + 37, Y - 32, 6, 6, "#E03131");

  // ลำตัว
  px(ctx, x, Y, W, H, "#1A1A2E");
  px(ctx, x + 4, Y + 4, W - 8, H - 8, "#5B2C8A");
  px(ctx, x + 4, Y + 4, W - 8, 8, "#7B3FA0");
  px(ctx, x + 4, Y + H - 16, W - 8, 12, "#3A1A5C");
  // เกล็ดบนตัว
  for (let r = 0; r < 3; r++)
    for (let c = 0; c < 4; c++)
      px(ctx, x + 12 + c * 16, Y + 56 + r * 10, 10, 6, "#4A2275");

  // ตาสีแดงเรืองแสง
  const blink = Math.floor(t / 50) % 8 === 0;
  if (!blink) {
    px(ctx, x + 14, Y + 20, 18, 16, "#FFFFFF");
    px(ctx, x + 48, Y + 20, 18, 16, "#FFFFFF");
    px(ctx, x + 20, Y + 24, 8, 9, "#E03131");
    px(ctx, x + 52, Y + 24, 8, 9, "#E03131");
    px(ctx, x + 22, Y + 26, 3, 3, "#FFFFFF");
    px(ctx, x + 54, Y + 26, 3, 3, "#FFFFFF");
  } else {
    px(ctx, x + 14, Y + 28, 18, 4, "#1A1A2E");
    px(ctx, x + 48, Y + 28, 18, 4, "#1A1A2E");
  }
  // คิ้วโกรธ
  px(ctx, x + 12, Y + 16, 22, 5, "#2A0F45");
  px(ctx, x + 46, Y + 16, 22, 5, "#2A0F45");

  // ปากและเขี้ยว
  px(ctx, x + 18, Y + 42, 44, 12, "#2A0F45");
  [0, 11, 22, 33].forEach((d) => px(ctx, x + 20 + d, Y + 42, 8, 10, "#FFFFFF"));

  // เขาสองข้าง
  px(ctx, x - 6, Y + 6, 8, 20, "#D6D6E6");
  px(ctx, x + W - 2, Y + 6, 8, 20, "#D6D6E6");

  // หลอดพลังบอส
  const barW = W + 20;
  const bx = x - 10;
  const by = Y - 44;
  px(ctx, bx, by, barW, 12, "#1A1A2E");
  px(ctx, bx + 2, by + 2, barW - 4, 8, "#4A1010");
  px(ctx, bx + 2, by + 2, Math.max(0, ((barW - 4) * hp) / maxHp), 8, "#E03131");
  px(ctx, bx + 2, by + 2, Math.max(0, ((barW - 4) * hp) / maxHp), 3, "#FF6B6B");
}

export function drawFlag(ctx: Ctx, x: number, y: number, height: number, raised: number) {
  // เสา
  px(ctx, x, y, 8, height, "#8A8A9E");
  px(ctx, x, y, 3, height, "#C4C4D4");
  // ลูกบอลยอดเสา
  px(ctx, x - 5, y - 12, 18, 12, "#FFD43B");
  px(ctx, x - 2, y - 9, 8, 5, "#FFF0A0");
  // ธง
  const fy = y + 14 + (1 - raised) * (height - 80);
  px(ctx, x + 8, fy, 52, 34, "#1A1A2E");
  px(ctx, x + 10, fy + 2, 48, 30, "#E03131");
  px(ctx, x + 10, fy + 2, 48, 6, "#FF6B6B");
  // ดาวบนธง
  px(ctx, x + 28, fy + 10, 12, 4, "#FFFFFF");
  px(ctx, x + 32, fy + 6, 4, 12, "#FFFFFF");
  px(ctx, x + 24, fy + 20, 20, 4, "#FFFFFF");
}

/* ─────────────────────────────────────────────
   EFFECTS
   ───────────────────────────────────────────── */

export function drawParticle(ctx: Ctx, x: number, y: number, size: number, color: string) {
  px(ctx, x, y, size, size, color);
}

export function drawFloatingText(
  ctx: Ctx,
  x: number,
  y: number,
  text: string,
  color: string,
  alpha: number
) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.font = "bold 16px 'Press Start 2P', monospace";
  ctx.textAlign = "center";
  ctx.lineWidth = 4;
  ctx.strokeStyle = "#1A1A2E";
  ctx.strokeText(text, x, y);
  ctx.fillStyle = color;
  ctx.fillText(text, x, y);
  ctx.restore();
}

export function drawProgressBar(
  ctx: Ctx,
  w: number,
  progress: number,
  flagIcon = true
) {
  const barW = w - 40;
  px(ctx, 20, 14, barW, 14, "#1A1A2E");
  px(ctx, 22, 16, barW - 4, 10, "#3A3A5E");
  px(ctx, 22, 16, (barW - 4) * progress, 10, "#FFC800");
  px(ctx, 22, 16, (barW - 4) * progress, 3, "#FFE066");
  // หัวผู้เล่น
  const hx = 20 + (barW - 8) * progress;
  px(ctx, hx, 11, 10, 8, "#E03131");
  px(ctx, hx + 1, 19, 8, 4, "#FFC79B");
  if (flagIcon) {
    px(ctx, 20 + barW - 6, 8, 3, 22, "#FFFFFF");
    px(ctx, 20 + barW - 3, 8, 10, 7, "#E03131");
  }
}
